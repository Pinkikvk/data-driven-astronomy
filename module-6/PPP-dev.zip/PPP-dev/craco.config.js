const path = require('path');

module.exports = {
    plugins: [
        {
            plugin: require('craco-styled-jsx'),
            options: {
                sass: false,
                cssFileSupport: true,
                cssFileTest: /\.styled\.(s)css$/,
            },
        },
    ],
    webpack: {
        alias: {
            '@': path.resolve(__dirname, 'src/'),
            '@common': path.resolve(__dirname, 'src/views/common/'),
            '@actions': path.resolve(__dirname, 'src/actions'),
            '@utils': path.resolve(__dirname, 'src/utils'),
        },
    },
    jest: {
        configure: {
            moduleNameMapper: {
                '^@(.*)$': '<rootDir>/src$1',
            },
        },
    },
};
