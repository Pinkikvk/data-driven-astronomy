import React, { PureComponent } from 'react';
import CenteredContainer from '@common/CenteredContainer';
import RouteButtons from '@common/RouteButtons';
import getColor from '@utils/getColor';
import {
    Accordion, Button, Card, Row, Col,
} from 'react-bootstrap';

class PurposeOfFormDraw1 extends PureComponent {
    render() {
        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <h5>
                    <strong>Purpose of this form:</strong>
                </h5>
                <p>
                    This form is to be completed by the authorized representative of the Applicant and submitted to your SBA
                    Participating Lender. Submission of the requested
                    information is required to make a determination regarding eligibility for financial assistance. Failure
                    to submit the information would affect that
                    determination.
                </p>
                <br/>
                <h5>
                    <strong>Instructions for completing this form:</strong>
                </h5>
                <p>
                    With respect to “purpose of the loan,” payroll costs consist of compensation to employees (whose
                    principal place of residence is the United States) in the form of salary, wages, commissions, or similar
                    compensation; cash tips or the equivalent (based on employer records of past tips or, in the absence of
                    such records, a reasonable, good-faith employer estimate of such tips); payment for vacation, parental,
                    family, medical, or sick leave (except those paid leave amounts for which a credit is allowed under
                    FFCRA Sections 7001 and 7003); allowance for separation or dismissal; payment for the provision of
                    employee benefits (including insurance premiums) consisting of group health care coverage, group life,
                    disability, vision, or dental insurance, and retirement benefits; payment of state and local taxes
                    assessed on compensation of employees; and, for an independent contractor or sole proprietor, wage,
                    commissions, income, or net earnings from self-employment or similar compensation.
                </p>
                <p>
                    For purposes of calculating “Average Monthly Payroll,” most Applicants will use the average monthly
                    payroll for 2019 or 2020, excluding costs over $100,000 on an annualized basis, as prorated for the
                    period during which the payments are made or the obligation to make the payments is incurred, for each
                    employee. For seasonal businesses, the Applicant may elect to instead use average total monthly payroll
                    for any twelve-week period selected by the Applicant between February 15, 2019 and February 15, 2020,
                    excluding costs over $100,000 on an annualized basis, as prorated for the period during which the
                    payments are made or the obligation to make the payments is incurred, for each employee. For new
                    businesses, average monthly payroll may be calculated using the time period from January 1, 2020 to
                    February 29, 2020, excluding costs over $100,000 on an annualized basis, as prorated for the period
                    during which the payments are made or the obligation to make the payments is incurred, for each
                    employee. For farmers and ranchers that operate as a sole proprietorship or as an independent
                    contractor, or who are eligible self-employed individuals and report farm income or expenses on a
                    Schedule F (or any equivalent successor IRS form), payroll costs are computed using eligible payroll
                    costs for employees, if any, plus the lesser of $100,000 and the difference between gross income and any
                    eligible payroll costs for employees, as reported on a Schedule F. For Applicants that file IRS Form
                    1040, Schedule C, payroll costs are computed using line 31 net profit amount, limited to $100,000, plus
                    any eligible payroll costs for employees. For Applicants that are partnerships, payroll costs are
                    computed using net earnings from self-employment of individual general partners, as reported on IRS Form
                    1065 K-1, reduced by section 179 expense deduction claimed, unreimbursed partnership expenses claimed,
                    and depletion claimed on oil and gas properties, multiplied by 0.9235, that is not more than $100,000,
                    plus any eligible payroll costs for employees.
                </p>
                <p>
                    For purposes of reporting Number of Employees, sole proprietors, self-employed individuals, and
                    independent contractors should include themselves as employees (i.e., the minimum number in the box
                    Number of Employees is one).
                </p>
                <p>
                    For purposes of reporting Year of Establishment, self-employed individuals and independent contractors
                    may enter “NA”.
                </p>
                <p>
                    For purposes of reporting NAICS Code, applicants must match the business activity code provided on their
                    IRS income tax filings, if applicable.
                </p>
                <p>
                    If Applicant is refinancing an Economic Injury Disaster Loan (EIDL): Add the outstanding amount of an
                    EIDL made between January 31, 2020 and April 3, 2020 to Loan Request as indicated on the form. Do not
                    add the amount of any EIDL Advance.
                </p>
                <p>
                    All parties listed below are considered owners of the Applicant, as well as “principals”:
                </p>
                <ul>
                    <li>For a sole proprietorship, the sole proprietor;</li>
                    <li>For a partnership, all general partners, and all limited partners owning 20% or more of the equity of the firm;</li>
                    <li>For a corporation, all owners of 20% or more of the corporation;</li>
                    <li>For limited liability companies, all members owning 20% or more of the company; and</li>
                    <li>Any Trustor (if the Applicant is owned by a trust).</li>
                </ul>
                <hr/>
                <Row>
                    <Col xs={12} lg={6}>
                        <div>
                            <p>
                                <strong>Here are the documents you should collect to be ready to submit your application:</strong>
                            </p>
                            <ol>
                                <li>Business bank account and routing number</li>
                                <li>Average monthly payroll costs</li>
                                <li>Business Tax ID and Owner SSNs</li>
                                <li>Supporting tax documents or payroll report</li>
                            </ol>
                        </div>
                    </Col>
                    <Col xs={12} lg={6}>
                        <p>
                            <strong>Helpful Tips & Links</strong>
                        </p>
                        <ul>
                            <li>Have all the necessary information ready before you begin the application</li>
                            <li>If you close your browser your entries will not be saved</li>
                            <li>Beware of your browser’s Autofill overriding your data</li>
                            <li>
                                <a href="https://home.treasury.gov/system/files/136/Top-line-Overview-of-First-Draw-PPP.pdf" target="_new">First Draw PPP Overview</a>
                            </li>
                            <li>
                                <a href="https://home.treasury.gov/system/files/136/Top-line-Overview-of-Second-Draw-PPP.pdf" target="_new">Second Draw PPP Overview</a>
                            </li>
                            <li>
                                <a href="https://www.sba.gov/funding-programs/loans/coronavirus-relief-options" target="_new">SBA Relief Options</a>
                            </li>
                        </ul>
                    </Col>
                </Row>
                <Row>
                    <Col xs={12} lg={6}>
                        <div>
                            <p>
                                <strong>To calculate your payroll costs, you should include: </strong>
                            </p>
                            <ul>
                                <li>Salary, wage, commission, or similar compensation</li>
                                <li>Payment of cash tips or equivalent</li>
                                <li>Payment for vacation, parental, family, medical, or sick leave</li>
                                <li>Allowance for dismissal or separation</li>
                                <li>Payment required for the provisions of group health care benefits, including insurance premiums</li>
                                <li>Payment of any retirement benefit</li>
                                <li>Payment of State or local tax assessed on the compensation of employees</li>
                                <li>For sole proprietors or independent contractors, income or compensation not in excess of $100,000 per employee</li>
                            </ul>
                        </div>
                    </Col>
                    <Col xs={12} lg={6}>
                        <div>
                            <p>
                                <strong>Lastly, you will need to upload one of the following supporting documentation used to calculate your average payroll costs:</strong>
                            </p>
                            <ul>
                                <li>If you are self-employed as a sole proprietor or independent contractor without employees: IRS Form 1040 Schedule C for 2019 or 2020</li>
                                <li>If you are a partnership without employees: 2019 Schedule K-1 (IRS Form 1065).</li>
                                <li>
                                    If you have employees (even as a partnership)IRS Form 940 for 2019 or 2020 or IRS Form
                                    941 for 2019 or 2020 (Since this is a quarterly form, you must include all four
                                    quarters. If you were established less than a year ago, you need to provide a Form 941
                                    for every quarter since you were established.) orIRS Form 944 for 2019 or 2020
                                </li>
                                <li>Payroll processor records from a PEO (Professional Employer Organization)</li>
                            </ul>
                        </div>
                    </Col>
                </Row>
                <p>
                    <i>Note: second-time borrowers can submit the same documentation from your first application.</i>
                </p>
                <div>
                    <Accordion>
                        <Card>
                            <Card.Header>
                                <Accordion.Toggle as={Button} variant="link" eventKey="0">
                                Additional Disclosures from the SBA
                                </Accordion.Toggle>
                            </Card.Header>
                            <Accordion.Collapse eventKey="0">
                                <Card.Body>
                                    <div className="disclosures">
                                        <style jsx>{`
                                        .disclosures {
                                            font-size: 13px;
                                        }
                                    `}</style>
                                        <p><strong>Paperwork Reduction Act</strong> – You are not required to respond to
                                        this collection of
                                        information unless it
                                        displays a currently valid OMB Control Number. The estimated time for completing
                                        this application,
                                        including gathering data needed, is 8 minutes. Comments about this time or the
                                        information requested
                                        should be sent to: Small Business Administration, Director, Records Management
                                        Division, 409 3rd St.,
                                        SW, Washington DC 20416, and/or SBA Desk Officer, Office of Management and
                                        Budget, New Executive Office
                                        Building, Washington DC 20503. <strong>PLEASE DO NOT SEND FORMS TO THESE
                                            ADDRESSES.</strong></p>
                                        <p><strong>Privacy Act (5 U.S.C. 552a)</strong> – Under the provisions of the
                                        Privacy Act, you are not
                                        required to provide your social security number. Failure to
                                        provide your social security number may not affect any right, benefit or
                                        privilege to which you are
                                        entitled. (But see Debt Collection Notice
                                        regarding taxpayer identification number below.) Disclosures of name and other
                                        personal identifiers are
                                        required to provide SBA with
                                        sufficient information to make a character determination. When evaluating
                                        character, SBA considers the
                                        person’s integrity, candor, and
                                        disposition toward criminal actions. Additionally, SBA is specifically
                                        authorized to verify your
                                        criminal history, or lack thereof, pursuant to
                                        section 7(a)(1)(B), 15 USC Section 636(a)(1)(B) of the Small Business Act (the
                                        Act).</p>
                                        <p><strong>Disclosure of Information</strong> – Requests for information about
                                        another party may be denied
                                        unless SBA has the written permission of the
                                        individual to release the information to the requestor or unless the information
                                        is subject to
                                        disclosure under the Freedom of Information Act.
                                        The Privacy Act authorizes SBA to make certain “routine uses” of information
                                        protected by that Act. One
                                        such routine use is the disclosure of
                                        information maintained in SBA’s system of records when this information
                                        indicates a violation or
                                        potential violation of law, whether civil,
                                        criminal, or administrative in nature. Specifically, SBA may refer the
                                        information to the appropriate
                                        agency, whether Federal, State, local or
                                        foreign, charged with responsibility for, or otherwise involved in
                                        investigation, prosecution,
                                        enforcement or prevention of such violations.
                                        Another routine use is disclosure to other Federal agencies conducting
                                        background checks but only to the
                                        extent the information is relevant to
                                        the requesting agencies' function. See, 74 F.R. 14890 (2009), and as amended
                                        from time to time for
                                        additional background and other routine
                                        uses. In addition, the CARES Act, requires SBA to register every loan made under
                                        the Paycheck Protection
                                        Act using the Taxpayer
                                        Identification Number (TIN) assigned to the borrower.</p>
                                        <p><strong>Debt Collection Act of 1982, Deficit Reduction Act of 1984 (31 U.S.C.
                                        3701 et seq. and other
                                        titles)</strong> – SBA must obtain your taxpayer
                                        identification number when you apply for a loan. If you receive a loan, and do
                                        not make payments as they
                                        come due, SBA may: (1) report the
                                        status of your loan(s) to credit bureaus, (2) hire a collection agency to
                                        collect your loan, (3) offset
                                        your income tax refund or other amounts
                                        due to you from the Federal Government, (4) suspend or debar you or your company
                                        from doing business
                                        with the Federal Government, (5)
                                        refer your loan to the Department of Justice, or (6) foreclose on collateral or
                                        take other action
                                        permitted in the loan instruments.</p>
                                        <p><strong>Right to Financial Privacy Act of 1978 (12 U.S.C. 3401)</strong> – The
                                        Right to Financial Privacy
                                        Act of 1978, grants SBA access rights to
                                        financial records held by financial institutions that are or have been doing
                                        business with you or your
                                        business including any financial
                                        Paycheck Protection Program
                                        Borrower Application Form
                                        4
                                        SBA Form 2483 (04/20)
                                        institutions participating in a loan or loan guaranty. SBA is only required
                                        provide a certificate of its
                                        compliance with the Act to a financial
                                        institution in connection with its first request for access to your financial
                                        records. SBA's access
                                        rights continue for the term of any approved
                                        loan guaranty agreement. SBA is also authorized to transfer to another
                                        Government authority any
                                        financial records concerning an approved
                                        loan or loan guarantee, as necessary to process, service or foreclose on a loan
                                        guaranty or collect on a
                                        defaulted loan guaranty.</p>
                                        <p><strong>Freedom of Information Act (5 U.S.C. 552)</strong> – This law provides,
                                        with some exceptions,
                                        that SBA must supply information reflected in agency files and records to a
                                        person requesting it.
                                        Information about approved loans that is generally released includes, among
                                        other things, statistics on
                                        our loan programs (individual borrowers are not identified in the statistics)
                                        and other information such
                                        as the names of the borrowers, the amount of the loan, and the type of the loan.
                                        Proprietary data on a
                                        borrower would not routinely be made available to third parties. All requests
                                        under this Act are to be
                                        addressed to the nearest SBA office and be identified as a Freedom of
                                        Information request.</p>
                                        <p><strong>Occupational Safety and Health Act (15 U.S.C. 651 et seq.)</strong> – The
                                        Occupational Safety and
                                        Health Administration (OSHA) can require
                                        businesses to modify facilities and procedures to protect employees. Businesses
                                        that do not comply may
                                        be fined, forced to cease operations,
                                        or prevented from starting operations. Signing this form is certification that
                                        the applicant, to the
                                        best of its knowledge, is in compliance with
                                        the applicable OSHA requirements, and will remain in compliance during the life
                                        of the loan.</p>
                                        <p><strong>Civil Rights (13 C.F.R. 112, 113, 117)</strong> – All businesses
                                        receiving SBA financial
                                        assistance must agree not to discriminate in any business
                                        practice, including employment practices and services to the public on the basis
                                        of categories cited in
                                        13 C.F.R., Parts 112, 113, and 117 of
                                        SBA Regulations. All borrowers must display the "Equal Employment Opportunity
                                        Poster" prescribed by SBA.
                                        </p>
                                        <p><strong>Equal Credit Opportunity Act (15 U.S.C. 1691)</strong> – Creditors are
                                        prohibited from
                                        discriminating against credit applicants on the basis of race,
                                        color, religion, national origin, sex, marital status or age (provided the
                                        applicant has the capacity to
                                        enter into a binding contract); because all
                                        or part of the applicant's income derives from any public assistance program; or
                                        because the applicant
                                        has in good faith exercised any right
                                        under the Consumer Credit Protection Act.</p>
                                        <p><strong>Debarment and Suspension Executive Order 12549; (2 CFR Part 180 and Part
                                        2700)</strong> – By
                                        submitting this loan application, you certify
                                        that neither the Applicant or any owner of the Applicant have within the past
                                        three years been: (a)
                                        debarred, suspended, declared ineligible or
                                        voluntarily excluded from participation in a transaction by any Federal Agency;
                                        (b) formally proposed
                                        for debarment, with a final
                                        determination still pending; (c) indicted, convicted, or had a civil judgment
                                        rendered against you for
                                        any of the offenses listed in the
                                        regulations or (d) delinquent on any amounts owed to the U.S. Government or its
                                        instrumentalities as of
                                        the date of execution of this
                                        certification.</p>
                                    </div>
                                </Card.Body>
                            </Accordion.Collapse>
                        </Card>
                    </Accordion>
                </div>
                <RouteButtons previousPath="/draw-selector" nextPath="/questions" />
            </CenteredContainer>
        );
    }
}

export default PurposeOfFormDraw1;
