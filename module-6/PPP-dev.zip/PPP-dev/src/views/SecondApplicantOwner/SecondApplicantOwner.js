import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import CenteredContainer from '@common/CenteredContainer';
import {
    Form,
} from 'react-bootstrap';
import getColor from '@utils/getColor';
import SecondBusinessOwner from './components/SecondBusinessOwner';
import SecondIndividualOwner from './components/SecondIndividualOwner';

class SecondApplicantOwner extends PureComponent {
    componentDidMount() {
        const { firstPrincipalState } = this.props.info;
        if (!firstPrincipalState) {
            this.props.history.push('/first-applicant-owner');
        }
    }

    constructor(props) {
        super(props);
        this.state = { ownerType: '' };

        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(event) {
        this.setState({ ownerType: event.target.value });
    }

    render() {
        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <h5>
                    <strong>Applicant Ownership:</strong>
                </h5>
                <br/>
                <strong>Owner 2:</strong>
                <br/><br/>
                <Form.Label>Owner Type</Form.Label>
                <Form.Control
                    label="Owner Type"
                    onChange={this.handleChange}
                    as="select"
                    value={this.state.ownerType}
                >
                    <option> -- Choose One -- </option>
                    <option value="Business">Business</option>
                    <option value="Individual">Individual</option>
                </Form.Control>
                <br/><br/>
                {this.state.ownerType === 'Business' ? (
                    <SecondBusinessOwner />
                ) : null}
                {this.state.ownerType === 'Individual' ? (
                    <SecondIndividualOwner />
                ) : null}
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { numberOfOwners, info } = state.user;
    return { numberOfOwners, info };
}

export default connect(mapStateToProps)(SecondApplicantOwner);
