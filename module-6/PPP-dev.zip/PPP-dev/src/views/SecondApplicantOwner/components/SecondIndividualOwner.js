import React, { PureComponent } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import RouteButtons from '@common/RouteButtons';
import { saveToState } from '@actions/actions';
import FormControl from '@common/FormControl';
import {
    Form, Col,
} from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

class SecondIndividualOwner extends PureComponent {
    constructor(props) {
        super(props);
        this.isSecondDrawPppLoan = this.isSecondDrawPppLoan.bind(this);
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    isSecondDrawPppLoan() {
        return this.props.info.secondDrawPppLoan;
    }

    render() {
        const {
            secondPrincipalFirstName,
            secondPrincipalLastName,
            secondPrincipalTitle,
            secondPrincipalOwnershipPercentage,
            secondPrincipalTIN,
            secondPrincipalTINType,
            secondPrincipalAddressLine1,
            secondPrincipalAddressLine2,
            secondPrincipalCity,
            secondPrincipalState,
            secondPrincipalZipCode,
            secondPrincipalAlienRegistrationNumber,
            secondPrincipalGender,
            secondPrincipalEthnicity,
            secondPrincipalRace,
            secondPrincipalVeteranStatus,
        } = this.props.info;

        const {
            secondPrincipalTINEndsWith,
        } = this.props.endsWith;

        const schema = Yup.object({
            secondPrincipalFirstName: Yup.string().required('This is a required field'),
            secondPrincipalLastName: Yup.string().required('This is a required field'),
            secondPrincipalTitle: Yup.string(),
            secondPrincipalOwnershipPercentage: Yup.number().min(20, 'Your entry must be at least 20').max(100, 'Your entry cannot be more than 100').required('This is a required field'),
            secondPrincipalTIN: Yup.string()
                .matches(/^\d{9}$/, 'Your entry must be a 9 digit number')
                .matches(new RegExp(`${secondPrincipalTINEndsWith}$`), `Your entry must ends with ${secondPrincipalTINEndsWith}`)
                .required('This is a required field'),
            secondPrincipalTINType: Yup.string().required('This is a required field'),
            secondPrincipalAddressLine1: Yup.string().required('This is a required field'),
            secondPrincipalAddressLine2: Yup.string(),
            secondPrincipalCity: Yup.string().required('This is a required field'),
            secondPrincipalState: Yup.string().required('This is a required field'),
            secondPrincipalZipCode: Yup.string().matches(/^\d{5}$/, 'Your entry must be a 5 digit number').required('This is a required field'),
            secondPrincipalAlienRegistrationNumber: Yup.string().matches(/^.{7,9}$/, 'Your entry must be between 7-9 numbers.'),
            secondPrincipalGender: Yup.string(),
            secondPrincipalEthnicity: Yup.string(),
            secondPrincipalRace: Yup.string(),
            secondPrincipalVeteranStatus: Yup.string(),
        });

        return (
            <Formik
                validateOnChange={false}
                validateOnBlur={false}
                validationSchema={schema}
                onSubmit={async (values) => {
                    const modifiedValues = {
                        secondPrincipalName: values.secondPrincipalName,
                        secondPrincipalFirstName: values.secondPrincipalFirstName,
                        secondPrincipalLastName: values.secondPrincipalLastName,
                        secondPrincipalTitle: values.secondPrincipalTitle,
                        secondPrincipalOwnershipPercentage: values.secondPrincipalOwnershipPercentage,
                        secondPrincipalTIN: values.secondPrincipalTIN,
                        secondPrincipalTINType: values.secondPrincipalTINType,
                        secondPrincipalBusinessType: values.secondPrincipalBusinessType,
                        secondPrincipalBusinessDateEstablished: values.secondPrincipalBusinessDateEstablished,
                        secondPrincipalAddressLine1: values.secondPrincipalAddressLine1,
                        secondPrincipalAddressLine2: values.secondPrincipalAddressLine2,
                        secondPrincipalCity: values.secondPrincipalCity,
                        secondPrincipalState: values.secondPrincipalState,
                        secondPrincipalZipCode: values.secondPrincipalZipCode,
                        secondPrincipalAlienRegistrationNumber: values.secondPrincipalAlienRegistrationNumber,
                        secondPrincipalGender: values.secondPrincipalGender,
                        secondPrincipalEthnicity: values.secondPrincipalEthnicity,
                        secondPrincipalRace: values.secondPrincipalRace,
                        secondPrincipalVeteranStatus: values.secondPrincipalVeteranStatus,
                    };
                    await this.props.dispatch(saveToState(modifiedValues));
                    if (this.isSecondDrawPppLoan()) {
                        this.props.history.push('/certifications-draw-2');
                    } else {
                        this.props.history.push('/certifications-draw-1');
                    }
                }}
                initialValues={{
                    secondPrincipalFirstName: secondPrincipalFirstName || '',
                    secondPrincipalLastName: secondPrincipalLastName || '',
                    secondPrincipalTitle: secondPrincipalTitle || '',
                    secondPrincipalOwnershipPercentage: secondPrincipalOwnershipPercentage || '',
                    secondPrincipalTIN: secondPrincipalTIN || '',
                    secondPrincipalTINType: secondPrincipalTINType || '',
                    secondPrincipalAddressLine1: secondPrincipalAddressLine1 || '',
                    secondPrincipalAddressLine2: secondPrincipalAddressLine2 || '',
                    secondPrincipalCity: secondPrincipalCity || '',
                    secondPrincipalState: secondPrincipalState || '',
                    secondPrincipalZipCode: secondPrincipalZipCode || '',
                    secondPrincipalAlienRegistrationNumber: secondPrincipalAlienRegistrationNumber || '',
                    secondPrincipalGender: secondPrincipalGender || '',
                    secondPrincipalEthnicity: secondPrincipalEthnicity || '',
                    secondPrincipalRace: secondPrincipalRace || '',
                    secondPrincipalVeteranStatus: secondPrincipalVeteranStatus || '',
                }}
            >
                {({
                    handleSubmit,
                    handleChange,
                    values,
                    touched,
                    errors,
                }) => (
                    <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                        <p className="text-small">
                            <img src="/dot.png" style={{ marginRight: 18 }} alt="Dot" />Required information
                        </p>
                        <br/>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="First Name"
                                    value={values.secondPrincipalFirstName}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalFirstName"
                                    isInvalid={!!errors.secondPrincipalFirstName}
                                    error={errors.secondPrincipalFirstName}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Last Name"
                                    value={values.secondPrincipalLastName}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalLastName"
                                    isInvalid={!!errors.secondPrincipalLastName}
                                    error={errors.secondPrincipalLastName}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Ownership Percentage"
                                    value={values.secondPrincipalOwnershipPercentage}
                                    onChange={handleChange}
                                    type="number"
                                    name="secondPrincipalOwnershipPercentage"
                                    isInvalid={!!errors.secondPrincipalOwnershipPercentage}
                                    error={errors.secondPrincipalOwnershipPercentage}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Title"
                                    value={values.secondPrincipalTitle}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalTitle"
                                    isInvalid={!!errors.secondPrincipalTitle}
                                    error={errors.secondPrincipalTitle}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN"
                                    value={values.secondPrincipalTIN}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalTIN"
                                    isInvalid={!!errors.secondPrincipalTIN}
                                    error={errors.secondPrincipalTIN}
                                    required
                                    placeholder={secondPrincipalTINEndsWith ? `Please enter TIN ending with ${secondPrincipalTINEndsWith}` : ''}
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN Type"
                                    onChange={handleChange}
                                    as="select"
                                    value={values.secondPrincipalTINType}
                                    name="secondPrincipalTINType"
                                    isInvalid={!!errors.secondPrincipalTINType}
                                    error={errors.secondPrincipalTINType}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="SSN">SSN</option>
                                    <option value="EIN">EIN</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 1"
                                    value={values.secondPrincipalAddressLine1}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="1234 Main St"
                                    name="secondPrincipalAddressLine1"
                                    isInvalid={!!errors.secondPrincipalAddressLine1}
                                    error={errors.secondPrincipalAddressLine1}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 2"
                                    value={values.secondPrincipalAddressLine2}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="Apartment, studio, or floor"
                                    name="secondPrincipalAddressLine2"
                                    isInvalid={!!errors.secondPrincipalAddressLine2}
                                    error={errors.secondPrincipalAddressLine2}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="City"
                                    value={values.secondPrincipalCity}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalCity"
                                    isInvalid={!!errors.secondPrincipalCity}
                                    error={errors.secondPrincipalCity}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="State"
                                    value={values.secondPrincipalState}
                                    onChange={handleChange}
                                    as="select"
                                    name="secondPrincipalState"
                                    isInvalid={!!errors.secondPrincipalState}
                                    error={errors.secondPrincipalState}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Zip Code"
                                    value={values.secondPrincipalZipCode}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalZipCode"
                                    isInvalid={!!errors.secondPrincipalZipCode}
                                    error={errors.secondPrincipalZipCode}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Alien Registration Number"
                                    value={values.secondPrincipalAlienRegistrationNumber}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalAlienRegistrationNumber"
                                    isInvalid={!!errors.secondPrincipalAlienRegistrationNumber}
                                    error={errors.secondPrincipalAlienRegistrationNumber}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Gender"
                                    value={values.secondPrincipalGender}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalGender"
                                    isInvalid={!!errors.secondPrincipalGender}
                                    error={errors.secondPrincipalGender}
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Ethnicity"
                                    value={values.secondPrincipalEthnicity}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalEthnicity"
                                    isInvalid={!!errors.secondPrincipalEthnicity}
                                    error={errors.secondPrincipalEthnicity}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Race"
                                    value={values.secondPrincipalRace}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalRace"
                                    isInvalid={!!errors.secondPrincipalRace}
                                    error={errors.secondPrincipalRace}
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Veteran"
                                    value={values.secondPrincipalVeteranStatus}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalVeteranStatus"
                                    isInvalid={!!errors.secondPrincipalVeteranStatus}
                                    error={errors.secondPrincipalVeteranStatus}
                                />
                            </Col>
                        </Form.Row>
                        <RouteButtons previousPath="/first-applicant-owner" />
                    </Form>
                )}
            </Formik>
        );
    }
}

function mapStateToProps(state) {
    const { info, endsWith } = state.user;
    return { info, endsWith };
}

export default withRouter(connect(mapStateToProps)(SecondIndividualOwner));
