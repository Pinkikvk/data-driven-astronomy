import React, { PureComponent } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import RouteButtons from '@common/RouteButtons';
import { saveToState } from '@actions/actions';
import FormControl from '@common/FormControl';
import {
    getUSYupDate, frontendToBackendDate, backendToFrontendDate, getBrowserDateFormat,
} from '@utils/dateUtils';
import {
    Form, Col,
} from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const schema = Yup.object({
    secondPrincipalName: Yup.string().required('This is a required field'),
    secondPrincipalFirstName: Yup.string().required('This is a required field'),
    secondPrincipalLastName: Yup.string().required('This is a required field'),
    secondPrincipalOwnershipPercentage: Yup.number().min(20, 'Your entry must be at least 20').max(100, 'Your entry cannot be more than 100').required('This is a required field'),
    secondPrincipalTIN: Yup.string().matches(/^\d{9}$/, 'Your entry must be a 9 digit number').required('This is a required field'),
    secondPrincipalTINType: Yup.string().required('This is a required field'),
    secondPrincipalBusinessType: Yup.string().required('This is a required field'),
    secondPrincipalBusinessDateEstablished: getUSYupDate().max(new Date(), 'Date cannot be in the future').required('This is a required field'),
    secondPrincipalNAICS: Yup.string().matches(/^\d{6}$/, 'Your entry must be a 6 digit number'),
    secondPrincipalAddressLine1: Yup.string().required('This is a required field'),
    secondPrincipalAddressLine2: Yup.string(),
    secondPrincipalCity: Yup.string().required('This is a required field'),
    secondPrincipalState: Yup.string().required('This is a required field'),
    secondPrincipalZipCode: Yup.string().matches(/^\d{5}$/, 'Your entry must be a 5 digit number').required('This is a required field'),
});

class SecondBusinessOwner extends PureComponent {
    constructor(props) {
        super(props);
        this.isSecondDrawPppLoan = this.isSecondDrawPppLoan.bind(this);
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    isSecondDrawPppLoan() {
        return this.props.info.secondDrawPppLoan;
    }

    render() {
        const {
            secondPrincipalName,
            secondPrincipalFirstName,
            secondPrincipalLastName,
            secondPrincipalOwnershipPercentage,
            secondPrincipalTIN,
            secondPrincipalTINType,
            secondPrincipalBusinessType,
            secondPrincipalBusinessDateEstablished,
            secondPrincipalNAICS,
            secondPrincipalAddressLine1,
            secondPrincipalAddressLine2,
            secondPrincipalCity,
            secondPrincipalState,
            secondPrincipalZipCode,
        } = this.props.info;

        return (
            <Formik
                validateOnChange={false}
                validateOnBlur={false}
                validationSchema={schema}
                onSubmit={async (values) => {
                    const modifiedValues = {
                        secondPrincipalName: values.secondPrincipalName,
                        secondPrincipalFirstName: values.secondPrincipalFirstName,
                        secondPrincipalLastName: values.secondPrincipalLastName,
                        secondPrincipalOwnershipPercentage: values.secondPrincipalOwnershipPercentage,
                        secondPrincipalTIN: values.secondPrincipalTIN,
                        secondPrincipalTINType: values.secondPrincipalTINType,
                        secondPrincipalBusinessType: values.secondPrincipalBusinessType,
                        secondPrincipalBusinessDateEstablished: frontendToBackendDate(values.secondPrincipalBusinessDateEstablished),
                        secondPrincipalNAICS: values.secondPrincipalNAICS,
                        secondPrincipalAddressLine1: values.secondPrincipalAddressLine1,
                        secondPrincipalAddressLine2: values.secondPrincipalAddressLine2,
                        secondPrincipalCity: values.secondPrincipalCity,
                        secondPrincipalState: values.secondPrincipalState,
                        secondPrincipalZipCode: values.secondPrincipalZipCode,
                    };
                    await this.props.dispatch(saveToState(modifiedValues));
                    if (this.isSecondDrawPppLoan()) {
                        this.props.history.push('/certifications-draw-2');
                    } else {
                        this.props.history.push('/certifications-draw-1');
                    }
                }}
                initialValues={{
                    secondPrincipalName: secondPrincipalName || '',
                    secondPrincipalFirstName: secondPrincipalFirstName || '',
                    secondPrincipalLastName: secondPrincipalLastName || '',
                    secondPrincipalOwnershipPercentage: secondPrincipalOwnershipPercentage || '',
                    secondPrincipalTIN: secondPrincipalTIN || '',
                    secondPrincipalTINType: secondPrincipalTINType || '',
                    secondPrincipalBusinessType: secondPrincipalBusinessType || '',
                    secondPrincipalBusinessDateEstablished: backendToFrontendDate(secondPrincipalBusinessDateEstablished) || '',
                    secondPrincipalNAICS: secondPrincipalNAICS || '',
                    secondPrincipalAddressLine1: secondPrincipalAddressLine1 || '',
                    secondPrincipalAddressLine2: secondPrincipalAddressLine2 || '',
                    secondPrincipalCity: secondPrincipalCity || '',
                    secondPrincipalState: secondPrincipalState || '',
                    secondPrincipalZipCode: secondPrincipalZipCode || '',
                }}
            >
                {({
                    handleSubmit,
                    handleChange,
                    values,
                    touched,
                    errors,
                }) => (
                    <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                        <p className="text-small">
                            <img src="/dot.png" style={{ marginRight: 18 }} alt="Dot" />Required information
                        </p>
                        <br/>
                        <Form.Row>
                            <Col xs={12} controlId="secondPrincipalBusinessType">
                                <FormControl
                                    label="Business Type"
                                    onChange={handleChange}
                                    as="select"
                                    value={values.secondPrincipalBusinessType}
                                    name="secondPrincipalBusinessType"
                                    isInvalid={!!errors.secondPrincipalBusinessType}
                                    error={errors.secondPrincipalBusinessType}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="Joint Venture">Joint Venture</option>
                                    <option value="Sole Proprietor">Sole Proprietor</option>
                                    <option value="Partnership">Partnership</option>
                                    <option value="C-Corp">C-Corp</option>
                                    <option value="S-Corp">S-Corp</option>
                                    <option value="LLC">LLC</option>
                                    <option value="Independent Contractor">Independent Contractor</option>
                                    <option value="501(c)(3) nonprofit">501(c)(3) nonprofit</option>
                                    <option value="501(c)(6) organization">501(c)(6) organization</option>
                                    <option value="501(c)(19) veterans organization">501(c)(19) veterans organization</option>
                                    <option value="Eligible self-employed individual">Eligible self-employed individual</option>
                                    <option value="Housing Cooperative">Housing Cooperative</option>
                                    <option value="Tribal business (sec. 31(b)(2)(C) of Small Business Act)">Tribal business (sec. 31(b)(2)(C) of Small Business Act)</option>
                                    <option value="Trust">Trust</option>
                                    <option value="Cooperative">Cooperative</option>
                                    <option value="Professional Association">Professional Association</option>
                                    <option value="LLP">LLP</option>
                                    <option value="Tenant in Common">Tenant in Common</option>
                                    <option value="Nonprofit Child Care">Nonprofit Child Care</option>
                                    <option value="Nonprofit Organization">Nonprofit Organization</option>
                                    <option value="Rollover Business Startup">Rollover Business Startup</option>
                                    <option value="Employee Stock Ownership Plan">Employee Stock Ownership Plan</option>
                                    <option value="Other">Other</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="First Name"
                                    value={values.secondPrincipalFirstName}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalFirstName"
                                    isInvalid={!!errors.secondPrincipalFirstName}
                                    error={errors.secondPrincipalFirstName}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Last Name"
                                    value={values.secondPrincipalLastName}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalLastName"
                                    isInvalid={!!errors.secondPrincipalLastName}
                                    error={errors.secondPrincipalLastName}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Business Name"
                                    value={values.secondPrincipalName}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalName"
                                    isInvalid={!!errors.secondPrincipalName}
                                    error={errors.secondPrincipalName}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Ownership Percentage"
                                    value={values.secondPrincipalOwnershipPercentage}
                                    onChange={handleChange}
                                    type="number"
                                    name="secondPrincipalOwnershipPercentage"
                                    isInvalid={!!errors.secondPrincipalOwnershipPercentage}
                                    error={errors.secondPrincipalOwnershipPercentage}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN"
                                    value={values.secondPrincipalTIN}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalTIN"
                                    isInvalid={!!errors.secondPrincipalTIN}
                                    error={errors.secondPrincipalTIN}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN Type"
                                    onChange={handleChange}
                                    as="select"
                                    value={values.secondPrincipalTINType}
                                    name="secondPrincipalTINType"
                                    isInvalid={!!errors.secondPrincipalTINType}
                                    error={errors.secondPrincipalTINType}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="SSN">SSN</option>
                                    <option value="EIN">EIN</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="NAICS Code"
                                    value={values.secondPrincipalNAICS}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalNAICS"
                                    isInvalid={!!errors.secondPrincipalNAICS}
                                    error={errors.secondPrincipalNAICS}
                                    required
                                />
                                <style jsx>{`
                                        .naicsLookup {
                                            font-size: 13px;
                                        }
                                    `}</style>
                                <a className="naicsLookup" href="https://www.naics.com/code-search" target="_new">NAICS Code Lookup</a>
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label={`Date of Establishment (${getBrowserDateFormat()})`}
                                    value={values.firstPrincipalBusinessDateEstablished}
                                    onChange={handleChange}
                                    type="date"
                                    name="firstPrincipalBusinessDateEstablished"
                                    isInvalid={!!errors.firstPrincipalBusinessDateEstablished}
                                    error={errors.firstPrincipalBusinessDateEstablished}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 1"
                                    value={values.secondPrincipalAddressLine1}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="1234 Main St"
                                    name="secondPrincipalAddressLine1"
                                    isInvalid={!!errors.secondPrincipalAddressLine1}
                                    error={errors.secondPrincipalAddressLine1}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 2"
                                    value={values.secondPrincipalAddressLine2}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="Apartment, studio, or floor"
                                    name="secondPrincipalAddressLine2"
                                    isInvalid={!!errors.secondPrincipalAddressLine2}
                                    error={errors.secondPrincipalAddressLine2}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={4}>
                                <FormControl
                                    label="City"
                                    value={values.secondPrincipalCity}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalCity"
                                    isInvalid={!!errors.secondPrincipalCity}
                                    error={errors.secondPrincipalCity}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={4}>
                                <FormControl
                                    label="State"
                                    value={values.secondPrincipalState}
                                    onChange={handleChange}
                                    as="select"
                                    name="secondPrincipalState"
                                    isInvalid={!!errors.secondPrincipalState}
                                    error={errors.secondPrincipalState}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </FormControl>
                            </Col>
                            <Col xs={12} lg={4}>
                                <FormControl
                                    label="Zip Code"
                                    value={values.secondPrincipalZipCode}
                                    onChange={handleChange}
                                    type="text"
                                    name="secondPrincipalZipCode"
                                    isInvalid={!!errors.secondPrincipalZipCode}
                                    error={errors.secondPrincipalZipCode}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <RouteButtons previousPath="/first-applicant-owner" />
                    </Form>
                )}
            </Formik>
        );
    }
}

function mapStateToProps(state) {
    const { info } = state.user;
    return { info };
}

export default withRouter(connect(mapStateToProps)(SecondBusinessOwner));
