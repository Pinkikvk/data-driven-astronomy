import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import CenteredContainer from '@common/CenteredContainer';
import FormControl from '@common/FormControl';
import RouteButtons from '@common/RouteButtons';
import { saveToState } from '@actions/actions';
import {
    Form, Row, Col,
} from 'react-bootstrap';
import getColor from '@utils/getColor';
import toBoolean from '@utils/toBoolean';
import { Formik } from 'formik';
import * as Yup from 'yup';
import mediaQuery from '@/utils/mediaQuery';

const firstDrawSchema = Yup.object({
    applicantIsEligible: Yup.string().matches(/(true)/).required(),
    applicantMeetsRevenueTestAndSizeStandard: Yup.string().matches(/(true)/).required(),
    ineligibleGeneral: Yup.string().matches(/(false)/).required(),
    ineligibleBadLoan: Yup.string().matches(/(false)/).required(),
    hasOtherBusinesses: Yup.string().required(),
    addendumA: Yup.string().when('hasOtherBusinesses', {
        is: 'true',
        then: Yup.string().required('This field is required.'),
    }),
    receivedEIDL: Yup.string().required(),
    addendumB: Yup.string().when('receivedEIDL', {
        is: 'true',
        then: Yup.string().required('This field is required.'),
    }),
    ineligibleCriminalCharges: Yup.string().matches(/(false)/).required(),
    ineligibleFelony: Yup.string().matches(/(false)/).required(),
    allEmployeesResidency: Yup.string().matches(/(true)/).required(),
    businessFranchiseStatus: Yup.string().required(),
    businessFranchiseinSBADirectory: Yup.string().required(),
    businessFranchiseCode: Yup.string().when('businessFranchiseinSBADirectory', {
        is: 'true',
        then: Yup.string().required('This field is required.'),
    }),
});

const secondDrawSchema = Yup.object({
    applicantIsEligible: Yup.string().matches(/(true)/).required(),
    applicantMeetsRevenueTestAndSizeStandard: Yup.string().matches(/(true)/).required(),
    ineligibleGeneral: Yup.string().matches(/(false)/).required(),
    ineligibleBadLoan: Yup.string().matches(/(false)/).required(),
    hasOtherBusinesses: Yup.string().required(),
    addendumA: Yup.string().when('hasOtherBusinesses', {
        is: 'true',
        then: Yup.string().required('This field is required.'),
    }),
    ineligibleCriminalCharges: Yup.string().matches(/(false)/).required(),
    ineligibleFelony: Yup.string().matches(/(false)/).required(),
    allEmployeesResidency: Yup.string().matches(/(true)/).required(),
    businessFranchiseStatus: Yup.string().required(),
    businessFranchiseinSBADirectory: Yup.string().required(),
    businessFranchiseCode: Yup.string().when('businessFranchiseinSBADirectory', {
        is: 'true',
        then: Yup.string().required('This field is required.'),
    }),
});

class Questions extends PureComponent {
    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    render() {
        const {
            secondDrawPppLoan,
        } = this.props.info;

        // Extract the values already in the store to use later as initialValues in the Formik element
        let {
            applicantIsEligible,
            applicantMeetsRevenueTestAndSizeStandard,
            ineligibleGeneral,
            ineligibleBadLoan,
            hasOtherBusinesses,
            addendumA,
            receivedEIDL,
            addendumB,
            ineligibleCriminalCharges,
            ineligibleFelony,
            allEmployeesResidency,
            businessFranchiseStatus,
            businessFranchiseinSBADirectory,
            businessFranchiseCode,
        } = this.props.info

        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <Formik
                    validateOnChange={false}
                    validateOnBlur={false}
                    validationSchema={secondDrawPppLoan ? secondDrawSchema : firstDrawSchema}
                    onSubmit={async (values, { validate }) => {
                        const modifiedValues = {
                            applicantIsEligible: toBoolean(values.applicantIsEligible),
                            applicantMeetsRevenueTestAndSizeStandard: toBoolean(values.applicantMeetsRevenueTestAndSizeStandard),
                            ineligibleGeneral: toBoolean(values.ineligibleGeneral),
                            ineligibleBadLoan: toBoolean(values.ineligibleBadLoan),
                            hasOtherBusinesses: toBoolean(values.hasOtherBusinesses),
                            addendumA: values.addendumA,
                            receivedEIDL: secondDrawPppLoan ? toBoolean(values.receivedEIDL) : null,
                            addendumB: secondDrawPppLoan ? values.addendumB : '',
                            ineligibleCriminalCharges: toBoolean(values.ineligibleCriminalCharges),
                            ineligibleFelony: toBoolean(values.ineligibleFelony),
                            allEmployeesResidency: toBoolean(values.allEmployeesResidency),
                            businessFranchiseStatus: toBoolean(values.businessFranchiseStatus),
                            businessFranchiseinSBADirectory: toBoolean(values.businessFranchiseinSBADirectory),
                            businessFranchiseCode: values.businessFranchiseCode,
                        };
                        await this.props.dispatch(saveToState(modifiedValues));
                        this.props.history.push('/applicant-entity');
                    }}
                    initialValues={{
                        // initialValues to prepopulate the form value. Some casting *has to be made* to match the radio typing (string)
                        applicantIsEligible: String(applicantIsEligible),
                        applicantMeetsRevenueTestAndSizeStandard: String(applicantMeetsRevenueTestAndSizeStandard),
                        ineligibleGeneral: String(ineligibleGeneral),
                        ineligibleBadLoan: String(ineligibleBadLoan),
                        hasOtherBusinesses: String(hasOtherBusinesses),
                        addendumA: addendumA,
                        receivedEIDL: String(receivedEIDL),
                        addendumB: addendumB,
                        ineligibleCriminalCharges: String(ineligibleCriminalCharges),
                        ineligibleFelony: String(ineligibleFelony),
                        allEmployeesResidency: String(allEmployeesResidency),
                        businessFranchiseStatus: String(businessFranchiseStatus),
                        businessFranchiseinSBADirectory: String(businessFranchiseinSBADirectory),
                        businessFranchiseCode: businessFranchiseCode,
                    }}
                >
                    {({
                        handleSubmit,
                        handleChange,
                        values,
                        touched,
                        errors,
                    }) => (
                        <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                            {secondDrawPppLoan ? (
                                <p>
                                    <i>If you answered "No" to questions (1), (2), or (8), you are not eligible for a PPP
                                        loan.
                                    </i><br/><i>If questions If you answered “Yes” to questions (3), (4), (6), or (7), you
                                    are not eligible for a PPP loan.</i>
                                </p>
                            ) : (
                                <p>
                                    <i>If you answered "No" to questions (1), (2), or (9), you are not eligible for a PPP
                                        loan.
                                    </i><br/><i>If questions If you answered “Yes” to questions (3), (4), (7), or (8), you
                                    are not eligible for a PPP loan.</i>
                                </p>
                            )}
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    1. Is the applicant business an eligible entity type?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="applicantIsEligible">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="applicantIsEligible"
                                            id="applicantIsEligibleYes"
                                            value={'true'}
                                            checked={values.applicantIsEligible === 'true'}
                                            isInvalid={!!errors.applicantIsEligible}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="applicantIsEligible"
                                            id="applicantIsEligibleNo"
                                            value={'false'}
                                            checked={values.applicantIsEligible === 'false'}
                                            isInvalid={!!errors.applicantIsEligible}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    2. Does the applicant meet the number of employee limitations set forth by the SBA?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="applicantMeetsRevenueTestAndSizeStandard">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="applicantMeetsRevenueTestAndSizeStandard"
                                            id="applicantMeetsRevenueTestAndSizeStandardYes"
                                            value={'true'}
                                            checked={values.applicantMeetsRevenueTestAndSizeStandard === 'true'}
                                            isInvalid={!!errors.applicantMeetsRevenueTestAndSizeStandard}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="applicantMeetsRevenueTestAndSizeStandard"
                                            id="applicantMeetsRevenueTestAndSizeStandardNo"
                                            value={'false'}
                                            checked={values.applicantMeetsRevenueTestAndSizeStandard === 'false'}
                                            isInvalid={!!errors.applicantMeetsRevenueTestAndSizeStandard}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    3. Is the Applicant or any owner of the Applicant presently suspended, debarred,
                                    proposed for debarment, declared ineligible,
                                    voluntarily excluded from participation in this transaction by any Federal
                                    department or agency, or presently involved in any
                                    bankruptcy?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="ineligibleGeneral">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="ineligibleGeneral"
                                            id="ineligibleGeneralYes"
                                            value={'true'}
                                            checked={values.ineligibleGeneral === 'true'}
                                            isInvalid={!!errors.ineligibleGeneral}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="ineligibleGeneral"
                                            id="ineligibleGeneralNo"
                                            value={'false'}
                                            checked={values.ineligibleGeneral === 'false'}
                                            isInvalid={!!errors.ineligibleGeneral}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    4. Has the Applicant, any owner of the Applicant, or any business owned or
                                    controlled by any of them, ever obtained a direct or guaranteed loan from SBA or any
                                    other Federal agency that is (a) currently delinquent, or (b) has defaulted in the
                                    last 7 years and caused a loss to the government?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="ineligibleBadLoan">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="ineligibleBadLoan"
                                            id="ineligibleBadLoanYes"
                                            value={'true'}
                                            checked={values.ineligibleBadLoan === 'true'}
                                            isInvalid={!!errors.ineligibleBadLoan}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="ineligibleBadLoan"
                                            id="ineligibleBadLoanNo"
                                            value={'false'}
                                            checked={values.ineligibleBadLoan === 'false'}
                                            isInvalid={!!errors.ineligibleBadLoan}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    5. Is the Applicant or any owner of the Applicant an owner of any other business, or
                                    have common management (including a
                                    management agreement) with any other business? If yes, list all such businesses
                                    (including their TINs if available) and describe the
                                    relationship below.
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="hasOtherBusinesses">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="hasOtherBusinesses"
                                            id="hasOtherBusinessesYes"
                                            value={'true'}
                                            checked={values.hasOtherBusinesses === 'true'}
                                            isInvalid={!!errors.hasOtherBusinesses}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="hasOtherBusinesses"
                                            id="hasOtherBusinessesNo"
                                            value={'false'}
                                            checked={values.hasOtherBusinesses === 'false'}
                                            isInvalid={!!errors.hasOtherBusinesses}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={12}>
                                    <Form.Group controlId="addendumA">
                                        <Form.Control
                                            as="textarea"
                                            rows={3}
                                            onChange={handleChange}
                                            name="addendumA"
                                            value={values.addendumA}
                                            isInvalid={!!errors.addendumA}
                                        />
                                        <Form.Control.Feedback type="invalid">
                                            {errors.addendumA}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                </Col>
                            </Row>
                            {secondDrawPppLoan ? null : (
                                <>
                                    <br/>
                                    <Row>
                                        <Col lg={9} xl={10}>
                                        6. Did the Applicant receive an SBA Economic Injury Disaster Loan between January
                                        31, 2020 and April 3, 2020? If yes, provide
                                        details below.
                                        </Col>
                                        <Col lg={3} xl={2} className="align-radio">
                                            <Form.Group controlId="receivedEIDL">
                                                <Form.Check
                                                    onChange={handleChange}
                                                    type="radio"
                                                    inline
                                                    label="Yes"
                                                    name="receivedEIDL"
                                                    id="receivedEIDLYes"
                                                    value={'true'}
                                                    checked={values.receivedEIDL === 'true'}
                                                    isInvalid={!!errors.receivedEIDL}
                                                />
                                                <Form.Check
                                                    onChange={handleChange}
                                                    type="radio"
                                                    inline
                                                    label="No"
                                                    name="receivedEIDL"
                                                    id="receivedEIDLNo"
                                                    value={'false'}
                                                    checked={values.receivedEIDL === 'false'}
                                                    isInvalid={!!errors.receivedEIDL}
                                                />
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <br/>
                                    <Row>
                                        <Col lg={12}>
                                            <Form.Group controlId="addendumB">
                                                <Form.Control
                                                    as="textarea"
                                                    rows={3}
                                                    onChange={handleChange}
                                                    name="addendumB"
                                                    value={values.addendumB}
                                                    isInvalid={!!errors.addendumB}
                                                />
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.addendumB}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                </>
                            )}
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    {secondDrawPppLoan ? '6.' : '7.'} Is the Applicant (if an individual) or any individual owning 20% or more of the
                                    equity of the Applicant presently incarcerated or, for any felony, presently subject
                                    to an indictment, criminal information, arraignment, or other means by which formal
                                    criminal charges are brought in any jurisdiction?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="ineligibleCriminalCharges">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="ineligibleCriminalCharges"
                                            id="ineligibleCriminalChargesYes"
                                            value={'true'}
                                            checked={values.ineligibleCriminalCharges === 'true'}
                                            isInvalid={!!errors.ineligibleCriminalCharges}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="ineligibleCriminalCharges"
                                            id="ineligibleCriminalChargesNo"
                                            value={'false'}
                                            checked={values.ineligibleCriminalCharges === 'false'}
                                            isInvalid={!!errors.ineligibleCriminalCharges}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    {secondDrawPppLoan ? '7.' : '8.'} Within the last 5 years, for any felony involving fraud, bribery, embezzlement,
                                    or a false statement in a loan application or an application for federal financial
                                    assistance, or within the last year, for any other felony, has the Applicant (if an
                                    individual) or any owner of the Applicant 1) been convicted; 2) pleaded guilty; 3)
                                    pleaded nolo contendere; or 4) commenced any form of parole or probation (including
                                    probation before judgment)?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="ineligibleFelony">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="ineligibleFelony"
                                            id="ineligibleFelonyYes"
                                            value={'true'}
                                            checked={values.ineligibleFelony === 'true'}
                                            isInvalid={!!errors.ineligibleFelony}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="ineligibleFelony"
                                            id="ineligibleFelonyNo"
                                            value={'false'}
                                            checked={values.ineligibleFelony === 'false'}
                                            isInvalid={!!errors.ineligibleFelony}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    {secondDrawPppLoan ? '8.' : '9.'} Is the United States the principal place of residence for all employees included
                                    in the Applicant’s payroll calculation?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="allEmployeesResidency">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="allEmployeesResidency"
                                            id="allEmployeesResidencyYes"
                                            value={'true'}
                                            checked={values.allEmployeesResidency === 'true'}
                                            isInvalid={!!errors.allEmployeesResidency}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="allEmployeesResidency"
                                            id="allEmployeesResidencyNo"
                                            value={'false'}
                                            checked={values.allEmployeesResidency === 'false'}
                                            isInvalid={!!errors.allEmployeesResidency}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    {secondDrawPppLoan ? '9.' : '10.'} Is the Applicant a franchise?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="businessFranchiseStatus">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="businessFranchiseStatus"
                                            id="businessFranchiseStatusYes"
                                            value={'true'}
                                            checked={values.businessFranchiseStatus === 'true'}
                                            isInvalid={!!errors.businessFranchiseStatus}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="businessFranchiseStatus"
                                            id="businessFranchiseStatusNo"
                                            value={'false'}
                                            checked={values.businessFranchiseStatus === 'false'}
                                            isInvalid={!!errors.businessFranchiseStatus}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col lg={9} xl={10}>
                                    {secondDrawPppLoan ? '10.' : '11.'} Is the Applicant a franchise that is listed in the SBA’s Franchise Directory?
                                </Col>
                                <Col lg={3} xl={2} className="align-radio">
                                    <Form.Group controlId="businessFranchiseinSBADirectory">
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="Yes"
                                            name="businessFranchiseinSBADirectory"
                                            id="businessFranchiseinSBADirectoryYes"
                                            value={'true'}
                                            checked={values.businessFranchiseinSBADirectory === 'true'}
                                            isInvalid={!!errors.businessFranchiseinSBADirectory}
                                        />
                                        <Form.Check
                                            onChange={handleChange}
                                            type="radio"
                                            inline
                                            label="No"
                                            name="businessFranchiseinSBADirectory"
                                            id="businessFranchiseinSBADirectoryNo"
                                            value={'false'}
                                            checked={values.businessFranchiseinSBADirectory === 'false'}
                                            isInvalid={!!errors.businessFranchiseinSBADirectory}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <Row>
                                <Col xs={12} lg={6} xl={4}>
                                    <FormControl
                                        label="If yes, enter the SBA Franchise Identifier Code here:"
                                        value={values.businessFranchiseCode}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessFranchiseCode"
                                        isInvalid={!!errors.businessFranchiseCode}
                                        error={errors.businessFranchiseCode}
                                    />
                                </Col>
                            </Row>
                            <Row className="justify-content-md-center">
                                <Col xs={12} lg={8} xl={6}>
                                    {Object.keys(errors).length !== 0 && <Form.Group>
                                        <Form.Control.Feedback type="invalid" className="error-message">
                                            Please verify the questions you've answered above. One or more are invalid.
                                        </Form.Control.Feedback>
                                    </Form.Group>}
                                </Col>
                            </Row>
                            <RouteButtons previousPath={secondDrawPppLoan ? '/purpose-of-form-draw-2' : '/purpose-of-form-draw-1'} />
                        </Form>
                    )}
                </Formik>
                <style global jsx>{`
                    .align-radio {
                        margin-top: 30px;
                        text-align: center;
                    }
                    @media (${mediaQuery.onDesktop}) {
                        .align-radio {
                            margin-top: 0;
                            text-align: right;
                        }
                    }
                    .error-message {
                        margin-top: 32px;
                        display: block;
                        text-align: center;
                    }
                `}</style>
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { info } = state.user;
    return { info };
}

export default connect(mapStateToProps)(Questions);
