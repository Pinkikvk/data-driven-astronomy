import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import CircularProgress from '@material-ui/core/CircularProgress';
import CenteredContainer from '@common/CenteredContainer';
import JarisButton from '@common/JarisButton';
import { PSClickWrap } from '@pactsafe/pactsafe-react-sdk';
import getColor from '@utils/getColor';
import { saveData } from '@actions/actions';

class AdditionalTerms extends PureComponent {
    constructor() {
        super();
        this.state = {
            contractSigned: false,
            isLoading: false,
        };
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {
        const { loanRequestIsNecessary, secondDrawPppLoan } = this.props.info;
        if (!loanRequestIsNecessary && secondDrawPppLoan) {
            this.props.history.push('/certifications-draw-2');
        } else if (!loanRequestIsNecessary) {
            this.props.history.push('/certifications-draw-1');
        }
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    async handleSubmit(event) {
        event.preventDefault();
        // Give feedback to the user
        this.setState({ isLoading: true });
        const { info, numberOfOwners } = this.props;
        await this.props.dispatch(saveData({ info, numberOfOwners }));
        this.props.history.push('/processed');
    }

    render() {
        const { info } = this.props;
        const { isLoading, contractSigned } = this.state;
        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                {isLoading ? (
                    <div style={{ textAlign: 'center' }}>
                        <CircularProgress />
                    </div>
                ) : (
                    <form onKeyPress={this.onKeyPress} onSubmit={this.handleSubmit}>
                        <h5>
                            <strong>Additional Terms</strong>
                        </h5>
                        <p>
                            I give Blue Ridge Bank, National Association and jaris Funding, LLC permission to access consumer reports and data related to me, the Company and the Company’s other beneficial owners for the purposes of this loan application, fraud prevention and compliance with other regulatory requirements.
                        </p>
                        <br/>
                        <PSClickWrap
                            accessId={process.env.REACT_APP_PACTSAFE_ACCESS_ID}
                            groupKey={process.env.REACT_APP_PACTSAFE_GROUP_KEY}
                            signerId={info.merchantId || info.userId}
                            onValid={() => {
                                this.setState({ contractSigned: true });
                            }}
                            onInvalid={() => {
                                this.setState({ contractSigned: false });
                            }}
                        />
                        <p>By clicking the “Accept and Submit” button:</p>
                        <ul>
                            <li>I confirm that I have read and agree to the terms related to this application</li>
                            <li>I confirm that neither me nor any of the company’s other beneficial owners have relied on any statements, representations, implications or otherwise made by Blue Ridge Bank, National Association, jaris Funding, LLC or any of their respective affiliates in connection with this application or the loan and that all representations and warranties are solely my own or made on behalf of the company.</li>
                            <li>I agree that the loan documents and subsequent terms and conditions can be presented to me electronically</li>
                        </ul>
                        <br/>
                        <div style={{ textAlign: 'center' }}>
                            <JarisButton
                                type="submit"
                                disabled={contractSigned ? undefined : true}
                            >
                                Accept and Submit
                            </JarisButton>
                        </div>
                    </form>)
                }
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { info, numberOfOwners } = state.user;
    return { info, numberOfOwners };
}

export default connect(mapStateToProps)(AdditionalTerms);
