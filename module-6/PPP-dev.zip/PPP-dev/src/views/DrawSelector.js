import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import RouteButtons from '@common/RouteButtons';
import CenteredContainer from '@common/CenteredContainer';
import JarisButton from '@common/JarisButton';
import { Col, Row } from 'react-bootstrap';
import { saveToState } from '@actions/actions';
import mediaQuery from '@/utils/mediaQuery';

class DrawSelector extends PureComponent {
    setIsSecondDrawPppLoan(isSecondDrawPppLoan) {
        const modifiedValues = { secondDrawPppLoan: isSecondDrawPppLoan };
        this.props.dispatch(saveToState(modifiedValues));
    }

    render() {
        const { secondDrawPppLoan } = this.props.info;
        const isFirstDraw = secondDrawPppLoan === false;
        const isSecondDraw = secondDrawPppLoan === true;
        const drawSettingMissing = secondDrawPppLoan === null;
        return (
            <CenteredContainer
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <Row className="justify-content-md-center">
                    <h4>Please select one of the options and press next below:</h4>
                </Row>
                <br/>
                <Row className="select-buttons-section">
                    <Col xs={12} lg={6}>
                        <div className="left-button">
                            <JarisButton secondary={!isFirstDraw} onClick={() => this.setIsSecondDrawPppLoan(false)}>
                                I am applying for my first PPP Loan
                            </JarisButton>
                        </div>
                        <br/>
                    </Col>
                    <Col xs={12} lg={6}>
                        <div>
                            <JarisButton secondary={!isSecondDraw} onClick={() => this.setIsSecondDrawPppLoan(true)}>
                                I am applying for my second PPP Loan
                            </JarisButton>
                        </div>
                    </Col>
                </Row>

                <Row>
                    <Col xs={12} lg={6}>
                        <div className={isFirstDraw ? 'selected-section section' : 'section'}>
                            <h5>
                                <strong>First-Time PPP Borrowers</strong>
                            </h5>
                            <br/>
                            <ul>
                                <li>The loan size will be 2.5x the average monthly payroll costs.</li>
                                <li>Max loan size for the Accommodation and Food Services industries could be up to 3.5x average monthly payroll.</li>
                                <li>Maximum amount of $10 million.</li>
                                <li>Criteria for loan forgiveness expanded.</li>
                            </ul>
                            <br/>
                            <p>
                                <strong>Requirements:</strong>
                            </p>
                            <ul>
                                <li>Business was in operation on February 15th, 2020.</li>
                                <li>Business has less than 500 employees.</li>
                            </ul>
                            <br/>
                            <p>
                                <strong>Loan Forgiveness:</strong>
                            </p>
                            <ul>
                                <li>Provide one page form to SBA certifying the number of employees borrower was able to retain because of loan, estimated amount of loan that was used on payroll, and the total loan amount.</li>
                                <li>Businesses must retain records to prove compliance with respect to employment records.</li>
                                <li>Certifies that it provided accurate information.</li>
                            </ul>
                        </div>
                        <br/>
                    </Col>
                    <Col xs={12} lg={6}>
                        <div className={isSecondDraw ? 'selected-section section' : 'section'}>
                            <h5>
                                <strong>Second-Time PPP Borrowers</strong>
                            </h5>
                            <br/>
                            <ul>
                                <li>Max loan size of 2.5x of average monthly payroll.</li>
                                <li>Max loan size for the Accommodation and Food Services industries could be up to 3.5x average monthly payroll.</li>
                                <li>Maximum amount of $2.0 million.</li>
                                <li>Criteria for loan forgiveness expanded.</li>
                            </ul>
                            <br/>
                            <p>
                                <strong>Requirements:</strong>
                            </p>
                            <ul>
                                <li>Business was in operation on February 15th, 2020.</li>
                                <li>Business has less than 300 employees.</li>
                                <li>Demonstrate a 25% reduction in revenue in 2020 compared to the same quarter in 2019.</li>
                                <li>The full amount of the previous PPP loan has been used.</li>
                            </ul>
                            <br/>
                            <p>
                                <strong>Loan Forgiveness:</strong>
                            </p>
                            <ul>
                                <li>May be provided if the company produces adequate documentation that it met the 25% reduction in revenue standard.</li>
                                <li>Businesses must retain records to prove compliance with respect to employment records.</li>
                                <li>Guidance to be provided by the SBA on additional requirements.</li>
                            </ul>
                        </div>

                    </Col>
                </Row>
                <Row className="justify-content-md-center">
                    <Col xs={12} lg={8} xl={6}>
                        {drawSettingMissing ? (
                            <span>
                                <i>Please select whether you are applying for a first or second PPP Loan above.</i>
                            </span>
                        ) : null}
                    </Col>
                </Row>
                <RouteButtons
                    disabledNext={drawSettingMissing}
                    previousPath="/"
                    nextPath={isFirstDraw ? '/purpose-of-form-draw-1' : '/purpose-of-form-draw-2' }
                />
                <style global jsx>{`
                    .select-buttons-section {
                        text-align:center;
                        margin-bottom: 30px;
                    }
                    .section {
                        padding: 15px;
                    }
                   .selected-section {
                       background-color: #ffd12d60;
                       border-radius: 5px;
                   }
                   .error-message {
                        margin-top: 32px;
                        display: block;
                        text-align: center;
                    }
                    @media (${mediaQuery.onDesktop}) {
                        .select-buttons-section {
                            text-align:left;
                        }
                        .left-button {
                            display: flex;
                            justify-content: flex-end;
                        }
                    }
                `}</style>
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { info } = state.user;

    return { info };
}

export default connect(mapStateToProps)(DrawSelector);
