import React from 'react';
import { connect } from 'react-redux';
import getColor from '@utils/getColor';

function Footer(props) {
    const { partner } = props;
    return (
        <div className="footer">
            <style jsx>{`
                .footer {
                    height: 65px;
                    background-color: ${getColor(`${partner}-background-color`)};
                }
            `}</style>
        </div>
    );
}

function mapStateToProps(state) {
    const { partner } = state.user;
    return { partner };
}

export default connect(mapStateToProps)(Footer);
