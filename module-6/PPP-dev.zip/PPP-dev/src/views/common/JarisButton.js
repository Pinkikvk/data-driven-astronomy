import React from 'react';
import Link from '@common/Link';

function JarisButton(props) {
    const {
        float = 'none', secondary, block, ...otherProps
    } = props;
    const width = block ? '100%' : 'fit-content';
    return (
        <>
            {props.to ? (
                <Link to={props.to}>
                    <button className={`jaris-button ${secondary ? 'jaris-button--secondary' : ''}`} {...otherProps}>
                        {props.children}
                    </button>
                </Link>
            ) : (
                <button className={`jaris-button ${secondary ? 'jaris-button--secondary' : ''}`} {...otherProps}>
                    {props.children}
                </button>
            )}
            <style jsx>{`
                .jaris-button {
                    padding: 0px 30px 0px 30px;
                    border: 0;
                    border-radius: 4px;
                    background-color: #ffd12d;
                    height: 50px;
                    width: ${width};
                    float: ${float};
                }
                .jaris-button--secondary {
                    background-color: #bdbdbd;
                }
                .jaris-button:focus {
                    outline: none;
                }
            `}</style>
        </>
    );
}

export default JarisButton;
