import React from 'react';
import {
    Form,
} from 'react-bootstrap';
import RequiredDotContainer from '@common/RequiredDotContainer';

function FormControl(props) {
    const {
        required,
        label,
        onChange,
        value,
        type,
        as,
        name,
        isInvalid,
        error,
        children,
        placeholder,
    } = props;

    const input = as === 'select' ? (
        <>
            <Form.Label>{label}</Form.Label>
            {required ? (
                <RequiredDotContainer type={as} isInvalid={isInvalid}>
                    <Form.Control
                        as="select"
                        value={value}
                        onChange={onChange}
                        type={type}
                        name={name}
                        isInvalid={isInvalid}
                    >
                        {children}
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                        {error}
                    </Form.Control.Feedback>
                </RequiredDotContainer>
            ) : (
                <>
                    <Form.Control
                        as="select"
                        value={value}
                        onChange={onChange}
                        type={type}
                        name={name}
                        isInvalid={isInvalid}
                    >
                        {children}
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                        {error}
                    </Form.Control.Feedback>
                </>
            )}
        </>
    ) : (
        <>
            <Form.Label>{label}</Form.Label>
            {required ? (
                <RequiredDotContainer type={type} isInvalid={isInvalid}>
                    <Form.Control
                        value={value}
                        onChange={onChange}
                        type={type}
                        name={name}
                        isInvalid={isInvalid}
                        placeholder={placeholder}
                    />
                    <Form.Control.Feedback type="invalid">
                        {error}
                    </Form.Control.Feedback>
                </RequiredDotContainer>
            ) : (
                <>
                    <Form.Control
                        value={value}
                        onChange={onChange}
                        type={type}
                        name={name}
                        isInvalid={isInvalid}
                        placeholder={placeholder}
                    />
                    <Form.Control.Feedback type="invalid">
                        {error}
                    </Form.Control.Feedback>
                </>
            )}
        </>
    );

    return input;
}

export default FormControl;
