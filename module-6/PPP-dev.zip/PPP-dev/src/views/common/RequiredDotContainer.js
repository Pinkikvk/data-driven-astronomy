import React from 'react';

function RequiredDotContainer(props) {
    const { children, type, isInvalid } = props;
    let right = '15px';
    if (type === 'select') {
        right = '25px';
    }
    if (type === 'date') {
        right = '45px';
    }
    if (isInvalid) {
        right = '30px';

        if (type === 'date') {
            right = '65px';
        }
    }

    return (
        <div className="required-dot-container">
            <img className="required-dot-text" src="/dot.png" alt="dot" />
            {children}
            <style jsx>{`
                .required-dot-container {
                    position: relative;
                }
                .required-dot-text {
                    z-index: 1;
                    position: absolute;
                    top: 13px;
                    right: ${right};
                }
            `}</style>
        </div>
    );
}

export default RequiredDotContainer;
