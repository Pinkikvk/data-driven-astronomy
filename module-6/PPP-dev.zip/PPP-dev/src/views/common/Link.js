import React from 'react';
import { Link as RouterLink } from 'react-router-dom';

function Link(props) {
    const { to, children } = props;
    return (
        <RouterLink to={to} style={{ color: 'inherit', textDecoration: 'inherit' }}>
            {children}
        </RouterLink>
    );
}

export default Link;
