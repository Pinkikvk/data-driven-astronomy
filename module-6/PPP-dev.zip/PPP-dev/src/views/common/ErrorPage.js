import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import CenteredContainer from '@common/CenteredContainer';
import getColor from '@utils/getColor';

// Generic error page
class ErrorPage extends PureComponent {
    render() {
        const { error } = this.props;

        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <div style={{ textAlign: 'center' }}>
                    <h5>
                        <strong>{error}</strong>
                    </h5>
                </div>
            </CenteredContainer>
        );
    }
}
function mapStateToProps(state) {
    const { error } = state.user;

    return { error };
}

export default connect(mapStateToProps)(ErrorPage);
