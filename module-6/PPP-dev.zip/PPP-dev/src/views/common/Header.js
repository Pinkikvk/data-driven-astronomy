import React from 'react';
import { connect } from 'react-redux';
import {
    Image,
} from 'react-bootstrap';
import useWindowSize from '@/hooks/useWindowSize';
import getColor from '@utils/getColor';
import mediaQuery from '@utils/mediaQuery';

function Header(props) {
    const { partner } = props;
    const windowSize = useWindowSize();
    const isMobile = windowSize.width < 992;
    return (
        <div style={{ color: getColor(`${partner}-text-color`), backgroundColor: getColor(`${partner}-background-color`) }}>
            <div className={'header-container'}>
                <div className="flex-child">
                    <Image
                        src={ partner === 'jaris' ? `${partner}.svg` : `${partner}.png`}
                        width={isMobile ? '107px' : '190px'}
                        style={{ marginRight: 30 }}
                    />
                </div>
                <br/>
                <div className="flex-child">
                    <div className={'header'}>
                        <h4>Paycheck Protection Program</h4>
                        Borrower Application Form
                    </div>
                </div>
                <br/>
                <div className="flex-child-2">
                    <div className={'header-support'}>
                        <div><strong>Need Help?</strong><br /><a href="mailto:support@jaris.io" className={'mailto'}>support@jaris.io</a></div>
                    </div>
                </div>
            </div>
            <style jsx>{`
                .header-container {
                    align-items: left;
                    display: flex;
                    flex-direction: column;
                    margin: 0 auto;
                    padding: 40px 40px 40px 40px;
                }
                .header-support {
                  font-size: 14px;
                }
                .header-support a {
                  color: white;
                }
                .flex-child {
                    flex: 1;
                }
                .flex-child-2 {
                    flex: 2;
                }
                @media(${mediaQuery.onDesktop}) {
                    .header-container {
                        align-items: center;
                        display: flex;
                        flex-direction: row;
                        max-width: 1490px;
                    }
                    .flex-child {
                        flex: none;
                    }
                    .header{
                        text-align: left;
                    }
                    .header-support {
                        text-align: right;
                    }
                }
            `}</style>
        </div>
    );
}

function mapStateToProps(state) {
    const { partner } = state.user;
    return { partner };
}

export default connect(mapStateToProps)(Header);
