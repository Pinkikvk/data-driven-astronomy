import React, { PureComponent } from 'react';
import { withRouter, Route } from 'react-router-dom';

class GARoute extends PureComponent {
    componentDidMount() {
        window.gtag('event', 'page_view', {
            page_title: this.props.history.location.pathname.substr(1) || 'welcome-page',
            page_path: window.location.pathname,
        });
    }

    render() {
        const { ...props } = this.props;
        return (
            <Route {...props} />
        );
    }
}

export default withRouter(GARoute);
