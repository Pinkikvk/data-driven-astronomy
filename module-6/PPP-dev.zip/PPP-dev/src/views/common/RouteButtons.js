import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

// Route buttons used throughout the ppp flow
class RouteButtons extends PureComponent {
    render() {
        const {
            previousPath,
            nextPath,
            disabledPrevious,
            disabledNext,
        } = this.props;

        return (
            <div className="route-buttons">
                <Link to={previousPath || '/'}>
                    <button
                        type="submit"
                        disabled={disabledPrevious}
                        className={disabledPrevious ? 'button route-button button-back disabled' : 'button route-button button-back'}
                    >
                        Back
                    </button>
                </Link>
                {nextPath ? (
                    <Link to={nextPath}>
                        <button
                            type="submit"
                            disabled={disabledNext}
                            className={disabledNext ? 'button route-button button-next disabled' : 'button route-button button-next'}
                        >
                            Next
                        </button>
                    </Link>
                ) : (
                    <button
                        type="submit"
                        disabled={disabledNext}
                        className={disabledNext ? 'button route-button button-next disabled' : 'button route-button button-next'}
                    >
                        Next
                    </button>
                )}
                <style jsx>{`
                    .route-buttons {
                        position: relative;
                        width: 35px;
                        margin: 0 auto;
                        margin-top: 35px;
                        padding-bottom: 65px;
                    }
                    .route-button {
                        background: #bdbdbd;
                        padding: 10px 55px;
                        border-radius: 20px;
                        border: none;
                        text-transform: uppercase;
                        font-size: 16px;
                        cursor: pointer;
                        font-style: normal;
                        font-weight: normal;
                        transition: color 0.2s ease-in;
                        outline: 0;
                    }
                    .route-button:hover {
                        color: black;
                    }
                    .route-button:disabled {
                        color: gray;
                    }
                    .button-back {
                        position: absolute;
                        right: 0;
                    }
                    .button-next {
                        background-color: #ffd12d;
                        position: absolute;
                        left: 0;
                    }
                    .disabled {
                        cursor: not-allowed;
                    }
                `}</style>
            </div>
        );
    }
}

RouteButtons.propTypes = {
    previousPath: PropTypes.string,
    nextPath: PropTypes.string,
    handleClick: PropTypes.func,
};

RouteButtons.defaultProps = {
    disabled: false,
    handleClick: () => false,
};

export default RouteButtons;
