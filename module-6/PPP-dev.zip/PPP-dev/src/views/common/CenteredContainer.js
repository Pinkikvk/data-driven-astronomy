import React from 'react';
import getColor from '@utils/getColor';
import mediaQuery from '@utils/mediaQuery';

export default function CenteredContainer({
    background,
    foreground,
    children,
    mobileMargins,
    desktopMargins,
}) {
    return (
        <div className="c-container">
            {children}
            <style jsx>{`
                .c-container {
                    height: 100%;
                    margin: 0 auto;
                    padding: ${mobileMargins};
                    background-color: ${getColor(background)};
                    color: ${getColor(foreground)};
                }
                @media(${mediaQuery.onDesktop}) {
                    .c-container {
                        max-width: 1490px;
                        padding: ${desktopMargins};
                    }
                }
            `}</style>
        </div>
    );
}
