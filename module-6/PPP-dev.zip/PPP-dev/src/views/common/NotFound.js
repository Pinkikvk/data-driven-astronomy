import React from 'react';
import CenteredContainer from '@common/CenteredContainer';
import JarisButton from '@common/JarisButton';
import getColor from '@utils/getColor';
import { Link } from 'react-router-dom';

// Generic not found page
function NotFound() {
    return (
        <CenteredContainer
            background={getColor('white')}
            foreground={getColor('dark')}
            desktopMargins={'65px 40px 65px 40px'}
            mobileMargins={'65px 40px 65px 40px'}
        >
            <div style={{ textAlign: 'center' }}>
                <h5>
                    <strong>Sorry, page not found!</strong>
                </h5>
                <br/>
                <Link to="/">
                    <JarisButton>
                        Back To Home
                    </JarisButton>
                </Link>
            </div>
        </CenteredContainer>
    );
}

export default NotFound;
