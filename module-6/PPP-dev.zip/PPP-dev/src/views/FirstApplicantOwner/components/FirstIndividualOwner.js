import React, { PureComponent } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import RouteButtons from '@common/RouteButtons';
import { saveToState } from '@actions/actions';
import FormControl from '@common/FormControl';
import {
    Form, Col,
} from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

class FirstIndividualOwner extends PureComponent {
    constructor(props) {
        super(props);
        this.isSecondDrawPppLoan = this.isSecondDrawPppLoan.bind(this);
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    isSecondDrawPppLoan() {
        return this.props.info.secondDrawPppLoan;
    }

    render() {
        const {
            firstPrincipalFirstName,
            firstPrincipalLastName,
            firstPrincipalTitle,
            firstPrincipalOwnershipPercentage,
            firstPrincipalTIN,
            firstPrincipalTINType,
            firstPrincipalAddressLine1,
            firstPrincipalAddressLine2,
            firstPrincipalCity,
            firstPrincipalState,
            firstPrincipalZipCode,
            firstPrincipalAlienRegistrationNumber,
            firstPrincipalGender,
            firstPrincipalEthnicity,
            firstPrincipalRace,
            firstPrincipalVeteranStatus,
        } = this.props.info;

        const {
            firstPrincipalTINEndsWith,
        } = this.props.endsWith;

        const {
            numberOfOwners,
        } = this.props;

        const schema = Yup.object({
            firstPrincipalFirstName: Yup.string().required('This is a required field'),
            firstPrincipalLastName: Yup.string().required('This is a required field'),
            firstPrincipalTitle: Yup.string(),
            firstPrincipalOwnershipPercentage: Yup.number().min(20, 'Your entry must be at least 20').max(100, 'Your entry cannot be more than 100').required('This is a required field'),
            firstPrincipalTIN: Yup.string()
                .matches(/^\d{9}$/, 'Your entry must be a 9 digit number')
                .matches(new RegExp(`${firstPrincipalTINEndsWith}$`), `Your entry must ends with ${firstPrincipalTINEndsWith}`)
                .required('This is a required field'),
            firstPrincipalTINType: Yup.string().required('This is a required field'),
            firstPrincipalAddressLine1: Yup.string().required('This is a required field'),
            firstPrincipalAddressLine2: Yup.string(),
            firstPrincipalCity: Yup.string().required('This is a required field'),
            firstPrincipalState: Yup.string().required('This is a required field'),
            firstPrincipalZipCode: Yup.string().matches(/^\d{5}$/, 'Your entry must be a 5 digit number').required('This is a required field'),
            firstPrincipalAlienRegistrationNumber: Yup.string().matches(/^.{7,9}$/, 'Your entry must be between 7-9 numbers.'),
            firstPrincipalGender: Yup.string(),
            firstPrincipalEthnicity: Yup.string(),
            firstPrincipalRace: Yup.string(),
            firstPrincipalVeteranStatus: Yup.string(),
        });

        return (
            <Formik
                validateOnChange={false}
                validateOnBlur={false}
                validationSchema={schema}
                onSubmit={async (values) => {
                    const modifiedValues = {
                        firstPrincipalName: values.firstPrincipalName,
                        firstPrincipalFirstName: values.firstPrincipalFirstName,
                        firstPrincipalLastName: values.firstPrincipalLastName,
                        firstPrincipalTitle: values.firstPrincipalTitle,
                        firstPrincipalOwnershipPercentage: values.firstPrincipalOwnershipPercentage,
                        firstPrincipalTIN: values.firstPrincipalTIN,
                        firstPrincipalTINType: values.firstPrincipalTINType,
                        firstPrincipalBusinessType: values.firstPrincipalBusinessType,
                        firstPrincipalBusinessDateEstablished: values.firstPrincipalBusinessDateEstablished,
                        firstPrincipalAddressLine1: values.firstPrincipalAddressLine1,
                        firstPrincipalAddressLine2: values.firstPrincipalAddressLine2,
                        firstPrincipalCity: values.firstPrincipalCity,
                        firstPrincipalState: values.firstPrincipalState,
                        firstPrincipalZipCode: values.firstPrincipalZipCode,
                        firstPrincipalAlienRegistrationNumber: values.firstPrincipalAlienRegistrationNumber,
                        firstPrincipalGender: values.firstPrincipalGender,
                        firstPrincipalEthnicity: values.firstPrincipalEthnicity,
                        firstPrincipalRace: values.firstPrincipalRace,
                        firstPrincipalVeteranStatus: values.firstPrincipalVeteranStatus,
                    };
                    await this.props.dispatch(saveToState(modifiedValues));
                    if (numberOfOwners === 2) {
                        this.props.history.push('/second-applicant-owner');
                    } else if (this.isSecondDrawPppLoan()) {
                        this.props.history.push('/certifications-draw-2');
                    } else {
                        this.props.history.push('/certifications-draw-1');
                    }
                }}
                initialValues={{
                    firstPrincipalFirstName: firstPrincipalFirstName || '',
                    firstPrincipalLastName: firstPrincipalLastName || '',
                    firstPrincipalTitle: firstPrincipalTitle || '',
                    firstPrincipalOwnershipPercentage: firstPrincipalOwnershipPercentage || '',
                    firstPrincipalTIN: firstPrincipalTIN || '',
                    firstPrincipalTINType: firstPrincipalTINType || '',
                    firstPrincipalAddressLine1: firstPrincipalAddressLine1 || '',
                    firstPrincipalAddressLine2: firstPrincipalAddressLine2 || '',
                    firstPrincipalCity: firstPrincipalCity || '',
                    firstPrincipalState: firstPrincipalState || '',
                    firstPrincipalZipCode: firstPrincipalZipCode || '',
                    firstPrincipalAlienRegistrationNumber: firstPrincipalAlienRegistrationNumber || '',
                    firstPrincipalGender: firstPrincipalGender || '',
                    firstPrincipalEthnicity: firstPrincipalEthnicity || '',
                    firstPrincipalRace: firstPrincipalRace || '',
                    firstPrincipalVeteranStatus: firstPrincipalVeteranStatus || '',
                }}
            >
                {({
                    handleSubmit,
                    handleChange,
                    values,
                    touched,
                    errors,
                }) => (
                    <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                        <p className="text-small">
                            <img src="/dot.png" style={{ marginRight: 18 }} alt="Dot" />Required information
                        </p>
                        <br/>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="First Name"
                                    value={values.firstPrincipalFirstName}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalFirstName"
                                    isInvalid={!!errors.firstPrincipalFirstName}
                                    error={errors.firstPrincipalFirstName}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Last Name"
                                    value={values.firstPrincipalLastName}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalLastName"
                                    isInvalid={!!errors.firstPrincipalLastName}
                                    error={errors.firstPrincipalLastName}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Ownership Percentage"
                                    value={values.firstPrincipalOwnershipPercentage}
                                    onChange={handleChange}
                                    type="number"
                                    name="firstPrincipalOwnershipPercentage"
                                    isInvalid={!!errors.firstPrincipalOwnershipPercentage}
                                    error={errors.firstPrincipalOwnershipPercentage}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Title"
                                    value={values.firstPrincipalTitle}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalTitle"
                                    isInvalid={!!errors.firstPrincipalTitle}
                                    error={errors.firstPrincipalTitle}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN"
                                    value={values.firstPrincipalTIN}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalTIN"
                                    isInvalid={!!errors.firstPrincipalTIN}
                                    error={errors.firstPrincipalTIN}
                                    required
                                    placeholder={firstPrincipalTINEndsWith ? `Please enter TIN ending with ${firstPrincipalTINEndsWith}` : ''}
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN Type"
                                    onChange={handleChange}
                                    as="select"
                                    value={values.firstPrincipalTINType}
                                    name="firstPrincipalTINType"
                                    isInvalid={!!errors.firstPrincipalTINType}
                                    error={errors.firstPrincipalTINType}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="SSN">SSN</option>
                                    <option value="EIN">EIN</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 1"
                                    value={values.firstPrincipalAddressLine1}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="1234 Main St"
                                    name="firstPrincipalAddressLine1"
                                    isInvalid={!!errors.firstPrincipalAddressLine1}
                                    error={errors.firstPrincipalAddressLine1}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 2"
                                    value={values.firstPrincipalAddressLine2}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="Apartment, studio, or floor"
                                    name="firstPrincipalAddressLine2"
                                    isInvalid={!!errors.firstPrincipalAddressLine2}
                                    error={errors.firstPrincipalAddressLine2}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="City"
                                    value={values.firstPrincipalCity}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalCity"
                                    isInvalid={!!errors.firstPrincipalCity}
                                    error={errors.firstPrincipalCity}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="State"
                                    value={values.firstPrincipalState}
                                    onChange={handleChange}
                                    as="select"
                                    name="firstPrincipalState"
                                    isInvalid={!!errors.firstPrincipalState}
                                    error={errors.firstPrincipalState}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Zip Code"
                                    value={values.firstPrincipalZipCode}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalZipCode"
                                    isInvalid={!!errors.firstPrincipalZipCode}
                                    error={errors.firstPrincipalZipCode}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Alien Registration Number"
                                    value={values.firstPrincipalAlienRegistrationNumber}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalAlienRegistrationNumber"
                                    isInvalid={!!errors.firstPrincipalAlienRegistrationNumber}
                                    error={errors.firstPrincipalAlienRegistrationNumber}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Gender"
                                    value={values.firstPrincipalGender}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalGender"
                                    isInvalid={!!errors.firstPrincipalGender}
                                    error={errors.firstPrincipalGender}
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Ethnicity"
                                    value={values.firstPrincipalEthnicity}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalEthnicity"
                                    isInvalid={!!errors.firstPrincipalEthnicity}
                                    error={errors.firstPrincipalEthnicity}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Race"
                                    value={values.firstPrincipalRace}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalRace"
                                    isInvalid={!!errors.firstPrincipalRace}
                                    error={errors.firstPrincipalRace}
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Veteran"
                                    value={values.firstPrincipalVeteranStatus}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalVeteranStatus"
                                    isInvalid={!!errors.firstPrincipalVeteranStatus}
                                    error={errors.firstPrincipalVeteranStatus}
                                />
                            </Col>
                        </Form.Row>
                        <RouteButtons previousPath="/application-details" />
                    </Form>
                )}
            </Formik>
        );
    }
}

function mapStateToProps(state) {
    const { info, numberOfOwners, endsWith } = state.user;
    return { info, numberOfOwners, endsWith };
}

export default withRouter(connect(mapStateToProps)(FirstIndividualOwner));
