import React, { PureComponent } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import RouteButtons from '@common/RouteButtons';
import { saveToState } from '@actions/actions';
import FormControl from '@common/FormControl';
import {
    getUSYupDate, frontendToBackendDate, backendToFrontendDate, getBrowserDateFormat,
} from '@utils/dateUtils';
import {
    Form, Col,
} from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const schema = Yup.object({
    firstPrincipalName: Yup.string().required('This is a required field'),
    firstPrincipalFirstName: Yup.string().required('This is a required field'),
    firstPrincipalLastName: Yup.string().required('This is a required field'),
    firstPrincipalOwnershipPercentage: Yup.number().min(20, 'Your entry must be at least 20').max(100, 'Your entry cannot be more than 100').required('This is a required field'),
    firstPrincipalTIN: Yup.string().matches(/^\d{9}$/, 'Your entry must be a 9 digit number').required('This is a required field'),
    firstPrincipalTINType: Yup.string().required('This is a required field'),
    firstPrincipalBusinessType: Yup.string().required('This is a required field'),
    firstPrincipalBusinessDateEstablished: getUSYupDate().max(new Date(), 'Date cannot be in the future').required('This is a required field'),
    firstPrincipalNAICS: Yup.string().matches(/^\d{6}$/, 'Your entry must be a 6 digit number'),
    firstPrincipalAddressLine1: Yup.string().required('This is a required field'),
    firstPrincipalAddressLine2: Yup.string(),
    firstPrincipalCity: Yup.string().required('This is a required field'),
    firstPrincipalState: Yup.string().required('This is a required field'),
    firstPrincipalZipCode: Yup.string().matches(/^\d{5}$/, 'Your entry must be a 5 digit number').required('This is a required field'),
});

class FirstBusinessOwner extends PureComponent {
    constructor(props) {
        super(props);
        this.isSecondDrawPppLoan = this.isSecondDrawPppLoan.bind(this);
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    isSecondDrawPppLoan() {
        return this.props.info.secondDrawPppLoan;
    }

    render() {
        const {
            firstPrincipalName,
            firstPrincipalFirstName,
            firstPrincipalLastName,
            firstPrincipalOwnershipPercentage,
            firstPrincipalTIN,
            firstPrincipalTINType,
            firstPrincipalBusinessType,
            firstPrincipalBusinessDateEstablished,
            firstPrincipalNAICS,
            firstPrincipalAddressLine1,
            firstPrincipalAddressLine2,
            firstPrincipalCity,
            firstPrincipalState,
            firstPrincipalZipCode,
        } = this.props.info;

        const {
            numberOfOwners,
        } = this.props;

        return (
            <Formik
                validateOnChange={false}
                validateOnBlur={false}
                validationSchema={schema}
                onSubmit={async (values) => {
                    const modifiedValues = {
                        firstPrincipalName: values.firstPrincipalName,
                        firstPrincipalFirstName: values.firstPrincipalFirstName,
                        firstPrincipalLastName: values.firstPrincipalLastName,
                        firstPrincipalOwnershipPercentage: values.firstPrincipalOwnershipPercentage,
                        firstPrincipalTIN: values.firstPrincipalTIN,
                        firstPrincipalTINType: values.firstPrincipalTINType,
                        firstPrincipalBusinessType: values.firstPrincipalBusinessType,
                        firstPrincipalBusinessDateEstablished: frontendToBackendDate(values.firstPrincipalBusinessDateEstablished),
                        firstPrincipalNAICS: values.firstPrincipalNAICS,
                        firstPrincipalAddressLine1: values.firstPrincipalAddressLine1,
                        firstPrincipalAddressLine2: values.firstPrincipalAddressLine2,
                        firstPrincipalCity: values.firstPrincipalCity,
                        firstPrincipalState: values.firstPrincipalState,
                        firstPrincipalZipCode: values.firstPrincipalZipCode,
                    };
                    await this.props.dispatch(saveToState(modifiedValues));
                    if (numberOfOwners === 2) {
                        this.props.history.push('/second-applicant-owner');
                    } else if (this.isSecondDrawPppLoan()) {
                        this.props.history.push('/certifications-draw-2');
                    } else {
                        this.props.history.push('/certifications-draw-1');
                    }
                }}
                initialValues={{
                    firstPrincipalName: firstPrincipalName || '',
                    firstPrincipalFirstName: firstPrincipalFirstName || '',
                    firstPrincipalLastName: firstPrincipalLastName || '',
                    firstPrincipalOwnershipPercentage: firstPrincipalOwnershipPercentage || '',
                    firstPrincipalTIN: firstPrincipalTIN || '',
                    firstPrincipalTINType: firstPrincipalTINType || '',
                    firstPrincipalBusinessType: firstPrincipalBusinessType || '',
                    firstPrincipalBusinessDateEstablished: backendToFrontendDate(firstPrincipalBusinessDateEstablished) || '',
                    firstPrincipalNAICS: firstPrincipalNAICS || '',
                    firstPrincipalAddressLine1: firstPrincipalAddressLine1 || '',
                    firstPrincipalAddressLine2: firstPrincipalAddressLine2 || '',
                    firstPrincipalCity: firstPrincipalCity || '',
                    firstPrincipalState: firstPrincipalState || '',
                    firstPrincipalZipCode: firstPrincipalZipCode || '',
                }}
            >
                {({
                    handleSubmit,
                    handleChange,
                    values,
                    touched,
                    errors,
                }) => (
                    <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                        <p className="text-small">
                            <img src="/dot.png" style={{ marginRight: 18 }} alt="Dot" />Required information
                        </p>
                        <br/>
                        <Form.Row>
                            <Col xs={12}>
                                <FormControl
                                    label="Business Type"
                                    onChange={handleChange}
                                    as="select"
                                    value={values.firstPrincipalBusinessType}
                                    name="firstPrincipalBusinessType"
                                    isInvalid={!!errors.firstPrincipalBusinessType}
                                    error={errors.firstPrincipalBusinessType}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="Joint Venture">Joint Venture</option>
                                    <option value="Sole Proprietor">Sole Proprietor</option>
                                    <option value="Partnership">Partnership</option>
                                    <option value="C-Corp">C-Corp</option>
                                    <option value="S-Corp">S-Corp</option>
                                    <option value="LLC">LLC</option>
                                    <option value="Independent Contractor">Independent Contractor</option>
                                    <option value="501(c)(3) nonprofit">501(c)(3) nonprofit</option>
                                    <option value="501(c)(6) organization">501(c)(6) organization</option>
                                    <option value="501(c)(19) veterans organization">501(c)(19) veterans organization</option>
                                    <option value="Eligible self-employed individual">Eligible self-employed individual</option>
                                    <option value="Housing Cooperative">Housing Cooperative</option>
                                    <option value="Tribal business (sec. 31(b)(2)(C) of Small Business Act)">Tribal business (sec. 31(b)(2)(C) of Small Business Act)</option>
                                    <option value="Trust">Trust</option>
                                    <option value="Cooperative">Cooperative</option>
                                    <option value="Professional Association">Professional Association</option>
                                    <option value="LLP">LLP</option>
                                    <option value="Tenant in Common">Tenant in Common</option>
                                    <option value="Nonprofit Child Care">Nonprofit Child Care</option>
                                    <option value="Nonprofit Organization">Nonprofit Organization</option>
                                    <option value="Rollover Business Startup">Rollover Business Startup</option>
                                    <option value="Employee Stock Ownership Plan">Employee Stock Ownership Plan</option>
                                    <option value="Other">Other</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="First Name"
                                    value={values.firstPrincipalFirstName}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalFirstName"
                                    isInvalid={!!errors.firstPrincipalFirstName}
                                    error={errors.firstPrincipalFirstName}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Last Name"
                                    value={values.firstPrincipalLastName}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalLastName"
                                    isInvalid={!!errors.firstPrincipalLastName}
                                    error={errors.firstPrincipalLastName}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Business Name"
                                    value={values.firstPrincipalName}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalName"
                                    isInvalid={!!errors.firstPrincipalName}
                                    error={errors.firstPrincipalName}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Ownership Percentage"
                                    value={values.firstPrincipalOwnershipPercentage}
                                    onChange={handleChange}
                                    type="number"
                                    name="firstPrincipalOwnershipPercentage"
                                    isInvalid={!!errors.firstPrincipalOwnershipPercentage}
                                    error={errors.firstPrincipalOwnershipPercentage}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN"
                                    value={values.firstPrincipalTIN}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalTIN"
                                    isInvalid={!!errors.firstPrincipalTIN}
                                    error={errors.firstPrincipalTIN}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="TIN Type"
                                    onChange={handleChange}
                                    as="select"
                                    value={values.firstPrincipalTINType}
                                    name="firstPrincipalTINType"
                                    isInvalid={!!errors.firstPrincipalTINType}
                                    error={errors.firstPrincipalTINType}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="SSN">SSN</option>
                                    <option value="EIN">EIN</option>
                                </FormControl>
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="NAICS Code"
                                    value={values.firstPrincipalNAICS}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalNAICS"
                                    isInvalid={!!errors.firstPrincipalNAICS}
                                    error={errors.firstPrincipalNAICS}
                                    required
                                />
                                <style jsx>{`
                                        .naicsLookup {
                                            font-size: 13px;
                                        }
                                    `}</style>
                                <a className="naicsLookup" href="https://www.naics.com/code-search" target="_new">NAICS Code Lookup</a>
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label={`Date of Establishment (${getBrowserDateFormat()})`}
                                    value={values.firstPrincipalBusinessDateEstablished}
                                    onChange={handleChange}
                                    type="date"
                                    name="firstPrincipalBusinessDateEstablished"
                                    isInvalid={!!errors.firstPrincipalBusinessDateEstablished}
                                    error={errors.firstPrincipalBusinessDateEstablished}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 1"
                                    value={values.firstPrincipalAddressLine1}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="1234 Main St"
                                    name="firstPrincipalAddressLine1"
                                    isInvalid={!!errors.firstPrincipalAddressLine1}
                                    error={errors.firstPrincipalAddressLine1}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={6}>
                                <FormControl
                                    label="Address Line 2"
                                    value={values.firstPrincipalAddressLine2}
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="Apartment, studio, or floor"
                                    name="firstPrincipalAddressLine2"
                                    isInvalid={!!errors.firstPrincipalAddressLine2}
                                    error={errors.firstPrincipalAddressLine2}
                                />
                            </Col>
                        </Form.Row>
                        <Form.Row>
                            <Col xs={12} lg={4}>
                                <FormControl
                                    label="City"
                                    value={values.firstPrincipalCity}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalCity"
                                    isInvalid={!!errors.firstPrincipalCity}
                                    error={errors.firstPrincipalCity}
                                    required
                                />
                            </Col>
                            <Col xs={12} lg={4}>
                                <FormControl
                                    label="State"
                                    value={values.firstPrincipalState}
                                    onChange={handleChange}
                                    as="select"
                                    name="firstPrincipalState"
                                    isInvalid={!!errors.firstPrincipalState}
                                    error={errors.firstPrincipalState}
                                    required
                                >
                                    <option value=""> -- Choose One -- </option>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </FormControl>
                            </Col>
                            <Col xs={12} lg={4}>
                                <FormControl
                                    label="Zip Code"
                                    value={values.firstPrincipalZipCode}
                                    onChange={handleChange}
                                    type="text"
                                    name="firstPrincipalZipCode"
                                    isInvalid={!!errors.firstPrincipalZipCode}
                                    error={errors.firstPrincipalZipCode}
                                    required
                                />
                            </Col>
                        </Form.Row>
                        <RouteButtons previousPath="/application-details" />
                    </Form>
                )}
            </Formik>
        );
    }
}

function mapStateToProps(state) {
    const { info, numberOfOwners } = state.user;
    return { info, numberOfOwners };
}

export default withRouter(connect(mapStateToProps)(FirstBusinessOwner));
