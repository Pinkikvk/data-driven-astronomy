import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import CenteredContainer from '@common/CenteredContainer';
import RouteButtons from '@common/RouteButtons';
import { saveToState, saveNumberOfOwners, uploadDocument } from '@actions/actions';
import FormControl from '@common/FormControl';
import {
    Form, Col, Popover, OverlayTrigger, Button,
} from 'react-bootstrap';
import getColor from '@utils/getColor';
import { Formik } from 'formik';
import * as Yup from 'yup';

const firstDrawSchema = Yup.object({
    averageMonthlyPayroll: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    numberOfEmployeesAtTimeOfApplication: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    anticipatedNumberOfEmployeesRetained: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    purposeOfLoanPayroll: Yup.bool(),
    purposeOfLoanMortgage: Yup.bool(),
    purposeOfLoanUtilities: Yup.bool(),
    purposeOfLoanCoveredOperationsExpenditures: Yup.bool(),
    purposeOfLoanCoveredPropertyDamage: Yup.bool(),
    purposeOfLoanCoveredSupplierCosts: Yup.bool(),
    purposeOfLoanCoveredWorkerProtectionExpenditure: Yup.bool(),
    purposeOfLoanOtherInfo: Yup.string(),
    numberOfOwners: Yup.string().required('This is a required field'),
    applicantMeetsSizeStandard: Yup.string().required('This is a required field'),
    refinanceofEIDLNetOfAdvance: Yup.string(),
});

const secondDrawSchema = Yup.object({
    averageMonthlyPayroll: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    numberOfEmployeesAtTimeOfApplication: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    anticipatedNumberOfEmployeesRetained: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    purposeOfLoanPayroll: Yup.bool(),
    purposeOfLoanMortgage: Yup.bool(),
    purposeOfLoanUtilities: Yup.bool(),
    purposeOfLoanCoveredOperationsExpenditures: Yup.bool(),
    purposeOfLoanCoveredPropertyDamage: Yup.bool(),
    purposeOfLoanCoveredSupplierCosts: Yup.bool(),
    purposeOfLoanCoveredWorkerProtectionExpenditure: Yup.bool(),
    purposeOfLoanOtherInfo: Yup.string(),
    numberOfOwners: Yup.string().required('This is a required field'),
    applicantMeetsSizeStandard: Yup.string().required('This is a required field'),
    refinanceofEIDLNetOfAdvance: Yup.string(),
    firstDrawSBALoanNumber: Yup.string().matches(/^\d{10}$/, 'Your entry must be a 10 digit number').required('This is a required field'),
    firstDrawSBALoanAmount: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    referenceQuarter: Yup.string().required('This is a required field'),
    twentyTwentyQuarter: Yup.string().required('This is a required field'),
    period1Revenue: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
    period2Revenue: Yup.number().positive('Your entry must be a positive number').required('This is a required field'),
});

const popover = (
    <Popover id="popover-basic">
        <Popover.Title as="h3">Documentation Guidelines</Popover.Title>
        <Popover.Content>
            <ul>
                <li>If you are self-employed as a sole proprietor or independent contractor without employees: IRS Form 1040 Schedule C for 2019 or 2020</li>
                <li>If you are a partnership without employees: 2019 Schedule K-1 (IRS Form 1065).</li>
                <li>If you have employees (even as a partnership) IRS Form 940 for 2019 or 2020 or IRS Form 941 for 2019 or 2020 (Since this is a quarterly form, you must include all four quarters. If you were established less than a year ago, you need to provide a Form 941 for every quarter since you were established.) or IRS Form 944 for 2019 or 2020</li>
                <li>Payroll processor records from a PEO (Professional Employer Organization)</li>
            </ul>
        </Popover.Content>
    </Popover>
);
const quarterPopover = (
    <Popover id="popover-quarter" style={{maxWidth: '500px'}}>
        <Popover.Title as="h3">2020 Period Information</Popover.Title>
        <Popover.Content>
            <ul>
                <li>For all entities other than those satisfying the conditions set forth below, Applicants must demonstrate that gross receipts in any quarter of 2020 were at least 25% lower than the same quarter of 2019. Alternatively, Applicants may compare annual gross receipts in 2020 with annual gross receipts in2019; Applicants choosing to use annual gross receipts must enter “Annual” in the 2020 Quarter and Reference Quarter fields and, as required documentation, must submit copies of annual tax forms substantiating the annual gross receipts reduction.</li>
                <li>For entities not in business during the first and second quarters of 2019 but in operation during the third and fourth quarters of 2019, Applicants must demonstrate that gross receipts in any quarter of 2020 were at least 25% lower than either the third or fourth quarters of 2019.</li>
                <li>For entities not in business during the first, second, and third quarters of 2019 but in operation during the fourth quarter of 2019, Applicants must demonstrate that gross receipts in any quarter of 2020 were at least 25% lower than the fourth quarter of 2019.</li>
                <li>For entities not in business during 2019 but in operation on February 15, 2020, Applicants must demonstrate that gross receipts in the second, third, or fourth quarter of 2020 were at least 25% lower than the first quarter of 2020.</li>
            </ul>
        </Popover.Content>
    </Popover>
);

class ApplicationDetails extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            purposeOfLoanError: false,
            fileUploadError: false,
            fileUploadErrorText: '',
        };
        this.onFileChange = this.onFileChange.bind(this);
        this.setPurposeOfLoanError = this.setPurposeOfLoanError.bind(this);
        this.setFileUploadError = this.setFileUploadError.bind(this);
        this.minPayrollFiles = this.minPayrollFiles.bind(this);
        this.getModifiedValues = this.getModifiedValues.bind(this);
        this.getModifiedValues = this.getModifiedValues.bind(this);
        this.loanAmountMutliplier = this.loanAmountMutliplier.bind(this);
    }

    componentDidMount() {
        const { businessState } = this.props.info;
        if (!businessState) {
            this.props.history.push('/applicant-entity');
        }
    }

    roundToTwo(num) {
        return +(`${Math.round(`${num}e+2`)}e-2`);
    }

    loanAmountMutliplier(averageMonthlyPayroll) {
        const { businessNAICSCode, secondDrawPppLoan } = this.props.info;
        const maxAmount = secondDrawPppLoan ? 2000000 : 10000000;
        let loanAmount;
        if (businessNAICSCode.substring(0, 2) === '72') {
            loanAmount = averageMonthlyPayroll * 3.5;
        } else {
            loanAmount = averageMonthlyPayroll * 2.5;
        }
        if (loanAmount > maxAmount) {
            return maxAmount;
        }
        return this.roundToTwo(loanAmount);
    }

    getModifiedValues(values) {
        const { secondDrawPppLoan } = this.props.info;
        if (secondDrawPppLoan) {
            return {
                averageMonthlyPayroll: parseFloat(values.averageMonthlyPayroll),
                loanAmount: this.loanAmountMutliplier(values.averageMonthlyPayroll),
                numberOfEmployeesAtTimeOfApplication: parseInt(values.numberOfEmployeesAtTimeOfApplication),
                anticipatedNumberOfEmployeesRetained: parseInt(values.anticipatedNumberOfEmployeesRetained),
                purposeOfLoanPayroll: values.purposeOfLoanPayroll,
                purposeOfLoanMortgage: values.purposeOfLoanMortgage,
                purposeOfLoanUtilities: values.purposeOfLoanUtilities,
                purposeOfLoanCoveredOperationsExpenditures: values.purposeOfLoanCoveredOperationsExpenditures,
                purposeOfLoanCoveredPropertyDamage: values.purposeOfLoanCoveredPropertyDamage,
                purposeOfLoanCoveredSupplierCosts: values.purposeOfLoanCoveredSupplierCosts,
                purposeOfLoanCoveredWorkerProtectionExpenditure: values.purposeOfLoanCoveredWorkerProtectionExpenditure,
                purposeOfLoanOther: values.purposeOfLoanOtherInfo.length > 0,
                purposeOfLoanOtherInfo: values.purposeOfLoanOtherInfo,
                applicantMeetsSizeStandard: values.applicantMeetsSizeStandard,
                refinanceofEIDLNetOfAdvance: values.refinanceofEIDLNetOfAdvance ? values.refinanceofEIDLNetOfAdvance : 0,
                firstDrawSBALoanNumber: values.firstDrawSBALoanNumber,
                firstDrawSBALoanAmount: parseFloat(values.firstDrawSBALoanAmount),
                referenceQuarter: values.referenceQuarter,
                twentyTwentyQuarter: values.twentyTwentyQuarter,
                period1Revenue: parseFloat(values.averageMonthlyPayroll),
                period2Revenue: parseFloat(values.averageMonthlyPayroll),
            };
        } else {
            return {
                averageMonthlyPayroll: parseFloat(values.averageMonthlyPayroll),
                loanAmount: parseFloat(values.averageMonthlyPayroll) * 2.5,
                numberOfEmployeesAtTimeOfApplication: parseInt(values.numberOfEmployeesAtTimeOfApplication),
                anticipatedNumberOfEmployeesRetained: parseInt(values.anticipatedNumberOfEmployeesRetained),
                purposeOfLoanPayroll: values.purposeOfLoanPayroll,
                purposeOfLoanMortgage: values.purposeOfLoanMortgage,
                purposeOfLoanUtilities: values.purposeOfLoanUtilities,
                purposeOfLoanCoveredOperationsExpenditures: values.purposeOfLoanCoveredOperationsExpenditures,
                purposeOfLoanCoveredPropertyDamage: values.purposeOfLoanCoveredPropertyDamage,
                purposeOfLoanCoveredSupplierCosts: values.purposeOfLoanCoveredSupplierCosts,
                purposeOfLoanCoveredWorkerProtectionExpenditure: values.purposeOfLoanCoveredWorkerProtectionExpenditure,
                purposeOfLoanOther: values.purposeOfLoanOtherInfo.length > 0,
                purposeOfLoanOtherInfo: values.purposeOfLoanOtherInfo,
                applicantMeetsSizeStandard: values.applicantMeetsSizeStandard,
                refinanceofEIDLNetOfAdvance: values.refinanceofEIDLNetOfAdvance ? values.refinanceofEIDLNetOfAdvance : 0,
            };
        }
    }

    minPayrollFiles(loanAmount) {
        const { secondDrawPppLoan, payrollFiles } = this.props.info;
        if (secondDrawPppLoan && loanAmount > 150000) {
            return payrollFiles.length >= 2;
        } else {
            return payrollFiles.length >= 1;
        }
    }

    setPurposeOfLoanError(value) {
        this.setState({ purposeOfLoanError: value });
    }

    setFileUploadError(value, loanAmount) {
        const { secondDrawPppLoan } = this.props.info;
        // Adds error
        if (value) {
            if (secondDrawPppLoan && loanAmount > 150000) {
                this.setState({ fileUploadError: value, fileUploadErrorText: 'For requested loan amounts over $150,000 you are required to submit both supporting payroll documents and quarterly income statements or bank statements that show the 25% reduction in revenue.' });
            } else {
                this.setState({ fileUploadError: value, fileUploadErrorText: 'You must upload at least one supporting payroll document' });
            }
        } else {
            // Removes error
            this.setState({ fileUploadError: value, fileUploadErrorText: '' });
        }
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    onFileChange(event) {
        // Upload the documents
        const { files } = event.target;

        for (let i = 0; i < files.length; i++) {
            this.props.dispatch(uploadDocument({
                file: files[i],
                fileName: files[i].name,
            }));
        }
    }

    render() {
        const {
            averageMonthlyPayroll,
            loanAmount,
            numberOfEmployeesAtTimeOfApplication,
            anticipatedNumberOfEmployeesRetained,
            purposeOfLoanPayroll,
            purposeOfLoanMortgage,
            purposeOfLoanUtilities,
            purposeOfLoanCoveredOperationsExpenditures,
            purposeOfLoanCoveredPropertyDamage,
            purposeOfLoanCoveredSupplierCosts,
            purposeOfLoanCoveredWorkerProtectionExpenditure,
            purposeOfLoanOtherInfo,
            applicantMeetsSizeStandard,
            receivedEIDL,
            refinanceofEIDLNetOfAdvance,
            secondDrawPppLoan,
            firstDrawSBALoanNumber,
            firstDrawSBALoanAmount,
            referenceQuarter,
            twentyTwentyQuarter,
            period1Revenue,
            period2Revenue,
            businessNAICSCode,
        } = this.props.info;

        const {
            numberOfOwners,
        } = this.props;

        const firstDrawInitValues = {
            numberOfOwners,
            averageMonthlyPayroll,
            loanAmount,
            numberOfEmployeesAtTimeOfApplication,
            anticipatedNumberOfEmployeesRetained,
            purposeOfLoanPayroll,
            purposeOfLoanMortgage,
            purposeOfLoanUtilities,
            purposeOfLoanCoveredOperationsExpenditures,
            purposeOfLoanCoveredPropertyDamage,
            purposeOfLoanCoveredSupplierCosts,
            purposeOfLoanCoveredWorkerProtectionExpenditure,
            purposeOfLoanOtherInfo,
            applicantMeetsSizeStandard,
            receivedEIDL,
            refinanceofEIDLNetOfAdvance,
        };

        const secondDrawInitValues = {
            numberOfOwners,
            averageMonthlyPayroll,
            loanAmount,
            numberOfEmployeesAtTimeOfApplication,
            anticipatedNumberOfEmployeesRetained,
            purposeOfLoanPayroll,
            purposeOfLoanMortgage,
            purposeOfLoanUtilities,
            purposeOfLoanCoveredOperationsExpenditures,
            purposeOfLoanCoveredPropertyDamage,
            purposeOfLoanCoveredSupplierCosts,
            purposeOfLoanCoveredWorkerProtectionExpenditure,
            purposeOfLoanOtherInfo,
            applicantMeetsSizeStandard,
            receivedEIDL,
            refinanceofEIDLNetOfAdvance,
            firstDrawSBALoanNumber,
            firstDrawSBALoanAmount,
            referenceQuarter,
            twentyTwentyQuarter,
            period1Revenue,
            period2Revenue,
        };

        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <h5>
                    <strong>Application Details:</strong>
                </h5><br/>
                <p className="text-small">
                    <img src="/dot.png" style={{ marginRight: 18 }} alt="Dot" />Required information
                </p>
                <br/>
                <Formik
                    validateOnChange={false}
                    validateOnBlur={false}
                    validationSchema={secondDrawPppLoan ? secondDrawSchema : firstDrawSchema}
                    onSubmit={async (values) => {
                        // Reset to no error for local state TODO be replace with something more elegant
                        this.setPurposeOfLoanError(false);
                        this.setFileUploadError(false);

                        const modifiedValues = await this.getModifiedValues(values);
                        const purposeOfLoansWhereTrue = Object.keys(modifiedValues).filter((key, index) => modifiedValues[key] === true);
                        // At least one purposeOfLoan was checked
                        // TODO be replace with something more elegant
                        if (purposeOfLoansWhereTrue.length >= 1 && this.minPayrollFiles(modifiedValues.loanAmount)) {
                            await this.props.dispatch(saveToState(modifiedValues));
                            await this.props.dispatch(saveNumberOfOwners(parseInt(values.numberOfOwners)));
                            this.props.history.push('/first-applicant-owner');
                        }
                        if (purposeOfLoansWhereTrue.length === 0) {
                            this.setPurposeOfLoanError(true);
                        }
                        if (!this.minPayrollFiles(modifiedValues.loanAmount)) {
                            this.setFileUploadError(true, modifiedValues.loanAmount);
                        }
                    }}
                    initialValues={secondDrawPppLoan ? secondDrawInitValues : firstDrawInitValues}
                >
                    {({
                        handleSubmit,
                        handleChange,
                        values,
                        touched,
                        errors,
                    }) => (
                        <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                            <Form.Label>
                                    Purpose of the loan (select more than one):
                            </Form.Label>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanPayroll}
                                        type="checkbox"
                                        label="Payroll"
                                        name="purposeOfLoanPayroll"
                                        id="purposeOfLoanPayroll"
                                        isInvalid={!!errors.purposeOfLoanPayroll}
                                    />
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanMortgage}
                                        type="checkbox"
                                        label="Lease / Mortgage Interest"
                                        name="purposeOfLoanMortgage"
                                        id="purposeOfLoanMortgage"
                                        isInvalid={!!errors.purposeOfLoanMortgage}
                                    />
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanUtilities}
                                        type="checkbox"
                                        label="Utilities"
                                        name="purposeOfLoanUtilities"
                                        id="purposeOfLoanUtilities"
                                        isInvalid={!!errors.purposeOfLoanMortgage}
                                    />
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanCoveredOperationsExpenditures}
                                        type="checkbox"
                                        label="Operations Expenditures"
                                        name="purposeOfLoanCoveredOperationsExpenditures"
                                        id="purposeOfLoanCoveredOperationsExpenditures"
                                        isInvalid={!!errors.purposeOfLoanCoveredOperationsExpenditures}
                                    />
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanCoveredPropertyDamage}
                                        type="checkbox"
                                        label="Property Damage"
                                        name="purposeOfLoanCoveredPropertyDamage"
                                        id="purposeOfLoanCoveredPropertyDamage"
                                        isInvalid={!!errors.purposeOfLoanCoveredPropertyDamage}
                                    />
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanCoveredSupplierCosts}
                                        type="checkbox"
                                        label="Supplier Costs"
                                        name="purposeOfLoanCoveredSupplierCosts"
                                        id="purposeOfLoanCoveredSupplierCosts"
                                        isInvalid={!!errors.purposeOfLoanCoveredSupplierCosts}
                                    />
                                    <Form.Check
                                        onChange={handleChange}
                                        value={values.purposeOfLoanCoveredWorkerProtectionExpenditure}
                                        type="checkbox"
                                        label="Worker Protection Expenditure"
                                        name="purposeOfLoanCoveredWorkerProtectionExpenditure"
                                        id="purposeOfLoanCoveredWorkerProtectionExpenditure"
                                        isInvalid={!!errors.purposeOfLoanCoveredWorkerProtectionExpenditure}
                                    />
                                    {
                                        <style jsx>{`
                                                .form-check-label {
                                                    min-width: 20em;
                                                }
                                            `}</style>
                                    }
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={4} xl={3}>
                                    <FormControl
                                        label="Other (Explain:)"
                                        value={values.purposeOfLoanOtherInfo}
                                        onChange={handleChange}
                                        type="string"
                                        name="purposeOfLoanOtherInfo"
                                        isInvalid={!!errors.purposeOfLoanOtherInfo}
                                        error={errors.purposeOfLoanOtherInfo}
                                    />
                                </Col>
                            </Form.Row>
                            {this.state.purposeOfLoanError ? (
                                <>
                                    <span className="custom-error">You must select at least one of these</span><br />
                                    <style jsx>{`
                                            .custom-error {
                                                width: 100%;
                                                margin-top: .25rem;
                                                font-size: 80%;
                                                color: #dc3545;
                                            }
                                            .form-label {
                                                margin-top: 15px;
                                            }
                                        `}</style>
                                </>
                            ) : null}
                            <br/>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Average Monthly Payroll ($)"
                                        value={values.averageMonthlyPayroll}
                                        onChange={handleChange}
                                        type="number"
                                        name="averageMonthlyPayroll"
                                        isInvalid={!!errors.averageMonthlyPayroll}
                                        error={errors.averageMonthlyPayroll}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <Form.Label>
                                            Loan Request Amount (Average Monthly Payroll {businessNAICSCode.substring(0, 2) === '72' ? 'x3.5' : 'x2.5'})
                                    </Form.Label>
                                    <Form.Control type="number" value={this.loanAmountMutliplier(values.averageMonthlyPayroll)} readOnly />
                                    <style jsx>{`
                                            .note {
                                                font-size: 13px;
                                            }
                                        `}</style>
                                    <span className="note">
                                            May not exceed {secondDrawPppLoan ? '$2,000,000' : '$10,000,000'}
                                    </span>
                                    <br/>
                                </Col>
                            </Form.Row>
                            {receivedEIDL ? (
                                <Form.Row>
                                    <Col xs={12}>
                                        <FormControl
                                            label="Field on application details Outstanding EIDL, Net of Advance (if applicable)"
                                            value={values.refinanceofEIDLNetOfAdvance}
                                            onChange={handleChange}
                                            type="number"
                                            name="refinanceofEIDLNetOfAdvance"
                                            isInvalid={!!errors.refinanceofEIDLNetOfAdvance}
                                            error={errors.refinanceofEIDLNetOfAdvance}
                                        />
                                    </Col>
                                </Form.Row>
                            ) : null}
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Current Number of Employees"
                                        value={values.numberOfEmployeesAtTimeOfApplication}
                                        onChange={handleChange}
                                        type="number"
                                        name="numberOfEmployeesAtTimeOfApplication"
                                        isInvalid={!!errors.numberOfEmployeesAtTimeOfApplication}
                                        error={errors.numberOfEmployeesAtTimeOfApplication}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Anticipated Number of Employees Retained"
                                        value={values.anticipatedNumberOfEmployeesRetained}
                                        onChange={handleChange}
                                        type="number"
                                        name="anticipatedNumberOfEmployeesRetained"
                                        isInvalid={!!errors.anticipatedNumberOfEmployeesRetained}
                                        error={errors.anticipatedNumberOfEmployeesRetained}
                                        required
                                    />
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Number of owners of 20% or more of equity"
                                        onChange={handleChange}
                                        as="select"
                                        value={values.numberOfOwners}
                                        isInvalid={!!errors.numberOfOwners}
                                        error={errors.numberOfOwners}
                                        required
                                        name="numberOfOwners"
                                    >
                                        <option value=""> -- Choose One -- </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                    </FormControl>
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Applicant Meets Size Standard"
                                        name="applicantMeetsSizeStandard"
                                        onChange={handleChange}
                                        as="select"
                                        value={values.applicantMeetsSizeStandard}
                                        isInvalid={!!errors.applicantMeetsSizeStandard}
                                        error={errors.applicantMeetsSizeStandard}
                                        required
                                    >
                                        <option> -- Choose One -- </option>
                                        <option value="No more than 500 employees (or 300 employees, if applicable)">No more than 500 employees (or 300 employees, if applicable)</option>
                                        <option value="SBA industry size standards">SBA industry size standards</option>
                                        <option value="SBA alternative size standard">SBA alternative size standard</option>
                                    </FormControl>
                                </Col>
                            </Form.Row>
                            {secondDrawPppLoan ? (
                                <>
                                    <Form.Row>
                                        <Col xs={12} lg={6}>
                                            <FormControl
                                                label="PPP First Draw SBA Loan Number"
                                                value={values.firstDrawSBALoanNumber}
                                                onChange={handleChange}
                                                type="string"
                                                name="firstDrawSBALoanNumber"
                                                isInvalid={!!errors.firstDrawSBALoanNumber}
                                                error={errors.firstDrawSBALoanNumber}
                                                required
                                            />
                                        </Col>
                                        <Col xs={12} lg={6}>
                                            <FormControl
                                                label="PPP First Draw SBA Loan Amount"
                                                value={values.firstDrawSBALoanAmount}
                                                onChange={handleChange}
                                                type="number"
                                                name="firstDrawSBALoanAmount"
                                                isInvalid={!!errors.firstDrawSBALoanAmount}
                                                error={errors.firstDrawSBALoanAmount}
                                                required
                                            />
                                        </Col>
                                    </Form.Row>
                                    <Form.Row>
                                        <Col xs={12} lg={6}>
                                            <FormControl
                                                label="2020 Period"
                                                name="twentyTwentyQuarter"
                                                onChange={handleChange}
                                                as="select"
                                                value={values.twentyTwentyQuarter}
                                                isInvalid={!!errors.twentyTwentyQuarter}
                                                error={errors.twentyTwentyQuarter}
                                                required
                                            >
                                                <option> -- Choose One -- </option>
                                                <option value="1Q 2020">1Q 2020</option>
                                                <option value="2Q 2020">2Q 2020</option>
                                                <option value="3Q 2020">3Q 2020</option>
                                                <option value="4Q 2020">4Q 2020</option>
                                                <option value="2020 Annual">2020 Annual</option>
                                            </FormControl>
                                            <OverlayTrigger
                                                placement="right"
                                                delay={{ show: 250, hide: 400 }}
                                                overlay={quarterPopover}
                                            >
                                                <Button variant="link">2020 Quarter Information</Button>
                                            </OverlayTrigger>
                                        </Col>
                                        <Col xs={12} lg={6}>
                                            <FormControl
                                                label="Reference Period"
                                                name="referenceQuarter"
                                                onChange={handleChange}
                                                as="select"
                                                value={values.referenceQuarter}
                                                isInvalid={!!errors.referenceQuarter}
                                                error={errors.referenceQuarter}
                                                required
                                            >
                                                <option> -- Choose One -- </option>
                                                <option value="1Q 2019">1Q 2019</option>
                                                <option value="2Q 2019">2Q 2019</option>
                                                <option value="3Q 2019">3Q 2019</option>
                                                <option value="4Q 2019">4Q 2019</option>
                                                <option value="2019 Annual">2019 Annual</option>
                                                <option value="1Q 2020">1Q 2020</option>
                                                <option value="2Q 2020">2Q 2020</option>
                                                <option value="3Q 2020">3Q 2020</option>
                                                <option value="4Q 2020">4Q 2020</option>
                                            </FormControl>
                                        </Col>
                                    </Form.Row>
                                    <Form.Row>
                                        <Col xs={12} lg={6}>
                                            <FormControl
                                                label="2020 Period Gross Receipts"
                                                value={values.period2Revenue}
                                                onChange={handleChange}
                                                type="number"
                                                name="period2Revenue"
                                                isInvalid={!!errors.period2Revenue}
                                                error={errors.period2Revenue}
                                                required
                                            />
                                        </Col>
                                        <Col xs={12} lg={6}>
                                            <FormControl
                                                label="Reference Period Gross Receipts"
                                                value={values.period1Revenue}
                                                onChange={handleChange}
                                                type="number"
                                                name="period1Revenue"
                                                isInvalid={!!errors.period1Revenue}
                                                error={errors.period1Revenue}
                                                required
                                            />
                                        </Col>
                                    </Form.Row>
                                </>
                            ) : null}
                            <br/>
                            <h5>Payroll Information</h5>
                            <Form.Label>Please upload any supporting documentation including payroll information.</Form.Label><br/>
                            <input type="file" onChange={this.onFileChange} multiple />
                            <br/>
                            {this.state.fileUploadError ? (
                                <>
                                    <span className="custom-error">{this.state.fileUploadErrorText}</span><br />
                                    <style jsx>{`
                                            .custom-error {
                                                width: 100%;
                                                margin-top: .25rem;
                                                font-size: 80%;
                                                color: #dc3545;
                                            }
                                            .form-label {
                                                margin-top: 15px;
                                            }
                                        `}</style>
                                </>
                            ) : null}
                            {secondDrawPppLoan && !this.state.fileUploadError && (this.loanAmountMutliplier(values.averageMonthlyPayroll) > 150000) ? (
                                <>
                                    <span className="custom-error">If your requested loan amount is over $150,000 you are required to submit quarterly income statements or bank statements that show the 25% reduction in revenue.</span><br />
                                    <style jsx>{`
                                            .custom-error {
                                                width: 100%;
                                                margin-top: .25rem;
                                                font-size: 80%;
                                            }
                                            .form-label {
                                                margin-top: 15px;
                                            }
                                        `}</style>
                                </>
                            ) : null}
                            <OverlayTrigger
                                placement="right"
                                delay={{ show: 250, hide: 400 }}
                                overlay={popover}
                            >
                                <Button variant="link">Payroll Documentation Guidelines</Button>
                            </OverlayTrigger>
                            <br />
                            <RouteButtons previousPath="/applicant-entity" />
                        </Form>
                    )}
                </Formik>
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { info, numberOfOwners, atLeastOnePayrollFile } = state.user;
    return { info, numberOfOwners, atLeastOnePayrollFile };
}

export default connect(mapStateToProps)(ApplicationDetails);
