import React from 'react';
import { connect } from 'react-redux';
import CenteredContainer from '@common/CenteredContainer';
import RouteButtons from '@common/RouteButtons';
import getColor from '@utils/getColor';
import { partnerMap } from '@/api-config/partners';
import {
    Image,
} from 'react-bootstrap';

function Welcome(props) {
    return (
        <CenteredContainer
            background={getColor('white')}
            foreground={getColor('dark')}
            desktopMargins={'65px 40px 65px 40px'}
            mobileMargins={'65px 40px 65px 40px'}
        >
            {!props.partner || !partnerMap[props.partner] ? (
                <>
                    Welcome to jaris. We are working with our partner, Blue Ridge Bank, to simplify your ability to get capital through the Paycheck Protection Program administered by the SBA.
                    Before we start, please note that by clicking the “Next” button below, you agree that you have read and agree to the <a href="https://jaris.io/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a>, <a href="https://jaris.io/terms-of-service" target="_blank" rel="noopener noreferrer">Terms and Conditions</a> and <a href="https://jaris.io/electronic-disclosures" target="_blank" rel="noopener noreferrer">Electronic Communications Consent</a>.
                </>
            ) : (
                <>
                    Welcome to {partnerMap[props.partner]}. We are working with our partners, jaris and Blue Ridge Bank, to simplify your ability to get capital through the Paycheck Protection Program administered by the SBA.
                    Before we start, please note that by clicking the “Next” button below, you agree that you have read and agree to the <a href="https://jaris.io/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a>, <a href="https://jaris.io/terms-of-service" target="_blank" rel="noopener noreferrer">Terms and Conditions</a> and <a href="https://jaris.io/electronic-disclosures" target="_blank" rel="noopener noreferrer">Electronic Communications Consent</a>.
                </>
            )}
            <br/>
            <div style={{ textAlign: 'center'}}>
                <strong>We are now accepting First and Second Draw PPP applications for all borrowers!</strong>
            </div>
            <br/>
            <RouteButtons disabledPrevious nextPath="/draw-selector" />
            <br/>
            <div style={{ textAlign: 'center' }}>
                <Image src="jaris-black.png" width="100px" style={{ marginRight: 30 }} />
                <Image src="blue-ridge-bank.png" width="152px" />
            </div>
        </CenteredContainer>
    );
}

function mapStateToProps(state) {
    const { partner } = state.user;
    return { partner };
}

export default connect(mapStateToProps)(Welcome);
