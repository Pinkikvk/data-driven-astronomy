import React, { PureComponent } from 'react';
import CenteredContainer from '@common/CenteredContainer';
import getColor from '@utils/getColor';

class Processed extends PureComponent {
    render() {
        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <h5>
                    <strong>You have successfully completed your application</strong>
                </h5>
                <p>
                    Typical time for the SBA to process your application is 3-5 days. Once the application is approved you will
                    receive an email with your loan agreement from Blue Ridge Bank and funds will be deposited to your account.
                </p>
            </CenteredContainer>
        );
    }
}

export default Processed;
