import React, { PureComponent } from 'react';
import CenteredContainer from '@common/CenteredContainer';
import { connect } from 'react-redux';
import RouteButtons from '@common/RouteButtons';
import { saveToState } from '@actions/actions';
import getColor from '@utils/getColor';
import {
    Form, Col, Row,
} from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const schema = Yup.object({
    certification1: Yup.string().required('Required'),
    certification2: Yup.string().required('Required'),
    certification3: Yup.string().required('Required'),
    certification4: Yup.string().required('Required'),
    certification5: Yup.string().required('Required'),
    certification6: Yup.string().required('Required'),
    certification7: Yup.string().required('Required'),
    certification8: Yup.string().required('Required'),
    certification9: Yup.string().required('Required'),
    certification10: Yup.string().required('Required'),

});

class CertificationsDraw1 extends PureComponent {
    componentDidMount() {
        const { numberOfOwners } = this.props;
        const { firstPrincipalFirstName, secondPrincipalFirstName } = this.props.info;
        if (!secondPrincipalFirstName && numberOfOwners === 2) {
            this.props.history.push('/second-applicant-owner');
        } else if (!firstPrincipalFirstName) {
            this.props.history.push('/first-applicant-owner');
        }
    }

    render() {
        const { numberOfOwners } = this.props;
        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <h5>
                    <strong>Certifications and Authorizations</strong>
                </h5>
                <br/>
                <p style={{ fontSize: '0.8em' }}><i>I certify that:</i></p>
                <ul>
                    <li>I have read the statements included in this form, including the Statements Required by Law and
                        Executive Orders, and I understand them.
                    </li>
                    <li>The Applicant is eligible to receive a loan under the rules in effect at the time this application
                        is submitted that have been issued by the Small
                        Business Administration (SBA) and the Department of the Treasury (Treasury) implementing the
                        Paycheck Protection Program under Division A, Title I of the Coronavirus Aid, Relief, and Economic
                        Security Act (CARES Act) and the Economic Aid to Hard-Hit Small Businesses, Nonprofits, and Venues
                        Act (the Paycheck Protection Program Rules).
                    </li>
                    <li>
                        The Applicant, together with its affiliates (if applicable), (1) is an independent contractor,
                        self-employed individual, or sole proprietor with no employees; (2) if not a housing cooperative,
                        eligible 501(c)(6) organization, or eligible destination marketing organization, employs no more
                        than the greater of 500 employees or, if applicable, the size standard in number of employees
                        established by SBA in 13 C.F.R. 121.201 for the Applicant’s industry; (3) if a housing cooperative,
                        eligible 501(c)(6) organization, or eligible destination marketing organization, employs no more
                        than 300 employees; (4) if NAICS 72, employs no more than 500 employees per physical location; (5)
                        if a news organization that is majority owned or controlled by a NAICS code 511110 or 5151 business
                        or a nonprofit public broadcasting entity with a trade or business under NAICS code 511110 or 5151,
                        employs no more than 500 employees (or, if applicable, the size standard in number of employees
                        established by SBA in 13 C.F.R. 121.201 for the Applicant’s industry) per location; or (6) is a
                        small business under the applicable revenue-based size standard established by SBA in 13 C.F.R.
                        121.201 for the Applicant’s industry or under the SBA alternative size standard.
                    </li>
                    <li>
                        I will comply, whenever applicable, with the civil rights and other limitations in this form.
                    </li>
                    <li>
                        All loan proceeds will be used only for business-related purposes as specified in the loan
                        application and consistent with the Paycheck Protection
                        Program Rules including the prohibition on using loan proceeds for lobbying activities and
                        expenditures. If Applicant is a news organization that became eligible for a loan under Section 317
                        of the Economic Aid to Hard-Hit Small Businesses, Nonprofits, and Venues Act, proceeds of the loan
                        will be used to support expenses at the component of the business concern that produces or
                        distributes locally focused or emergency information.
                    </li>
                    <li>
                        I understand that SBA encourages the purchase, to the extent feasible, of American-made equipment
                        and products.
                    </li>
                    <li>
                        The Applicant is not engaged in any activity that is illegal under federal, state or local law.
                    </li>
                    <li>
                        Any EIDL loan received by the Applicant (Section 7(b)(2) of the Small Business Act) between January
                        31, 2020 and April 3, 2020 was for a
                        purpose other than paying payroll costs and other allowable uses for loans under the Paycheck
                        Protection Program Rules.
                    </li>
                </ul>
                <p>For Applicants who are individuals: I authorize the SBA to request criminal record information about me
                    from criminal justice agencies for the purpose of determining my eligibility for programs authorized by
                    the Small Business Act, as amended.</p>
                <br/>
                <p style={{ fontSize: '0.8em' }}><i>The authorized representative of the Applicant must certify in good faith
                    to all of the below:</i></p>
                <br/>
                <Formik
                    validateOnChange={false}
                    validateOnBlur={false}
                    validationSchema={schema}
                    onSubmit={async (values) => {
                        const modifiedValues = {
                            loanRequestIsNecessary: true,
                            applicantNoShutteredVenueGrant: true,
                        };
                        await this.props.dispatch(saveToState(modifiedValues));
                        this.props.history.push('/additional-terms');
                    }}
                    initialValues={{}}
                >
                    {({
                        handleSubmit,
                        handleChange,
                        values,
                        touched,
                        errors,
                    }) => (
                        <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification1">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            isInvalid={!!errors.certification1}
                                            feedback={errors.certification1}
                                            name="certification1"
                                            id="certification1"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            The Applicant was in operation on February 15, 2020, has not permanently closed, and was either
                            an eligible self-employed individual, independent contractor, or sole proprietorship with no
                            employees, or had employees for whom it paid salaries and payroll taxes or paid independent
                            contractors, as reported on Form(s) 1099-MISC.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification2">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification2}
                                            isInvalid={!!errors.certification2}
                                            name="certification2"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            Current economic uncertainty makes this loan request necessary to support the ongoing operations
                            of the Applicant.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification3">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification3}
                                            isInvalid={!!errors.certification3}
                                            name="certification3"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            The funds will be used to retain workers and maintain payroll; or make payments for mortgage
                            interest, rent, utilities, covered operations expenditures, covered property damage costs,
                            covered supplier costs, and covered worker protection expenditures as specified under the
                            Paycheck Protection Program Rules; I understand that if the funds are knowingly used for
                            unauthorized purposes, the federal government may hold me legally liable, such as for charges of
                            fraud.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification4">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification4}
                                            isInvalid={!!errors.certification4}
                                            name="certification4"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            I understand that loan forgiveness will be provided for the sum of documented payroll costs,
                            covered mortgage interest payments, covered rent payments, covered utilities, covered operations
                            expenditures, covered property damage costs, covered supplier costs, and covered worker
                            protection expenditures, and not more than 40% of the forgiven amount may be for non-payroll
                            costs. If required, the Applicant will provide to the Lender and/or SBA documentation verifying
                            the number of full-time equivalent employees on the Applicant’s payroll as well as the dollar
                            amounts of eligible expenses for the covered period following this loan.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification5">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification5}
                                            isInvalid={!!errors.certification5}
                                            name="certification5"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            The Applicant has not and will not receive another loan under the Paycheck Protection Program,
                            section 7(a)(36) of the Small Business Act (15 U.S.C. 636(a)(36)) (this does not include
                            Paycheck Protection Program second draw loans, section 7(a)(37) of the Small Business Act (15
                            U.S.C. 636(a)(37)).
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification6">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification6}
                                            isInvalid={!!errors.certification6}
                                            name="certification6"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            The Applicant has not and will not receive a Shuttered Venue Operator grant from SBA.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification7">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification7}
                                            isInvalid={!!errors.certification7}
                                            name="certification7"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            The President, the Vice President, the head of an Executive department, or a Member of Congress,
                            or the spouse of such person as determined under applicable common law, does not directly or
                            indirectly hold a controlling interest in the Applicant, with such terms having the meanings
                            provided in Section 322 of the Economic Aid to Hard-Hit Small Businesses, Nonprofits, and Venues
                            Act.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification8">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification8}
                                            isInvalid={!!errors.certification8}
                                            name="certification8"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            The Applicant is not an issuer, the securities of which are listed on an exchange registered as
                            a national securities exchange under section 6 of the Securities Exchange Act of 1934 (15 U.S.C.
                            78f).
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification9">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification9}
                                            isInvalid={!!errors.certification9}
                                            name="certification9"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            I further certify that the information provided in this application and the information provided
                            in all supporting documents and forms is true and accurate in all material respects. I
                            understand that knowingly making a false statement to obtain a guaranteed loan from SBA is
                            punishable under the law, including under 18 U.S.C. 1001 and 3571 by imprisonment of not more
                            than five years and/or a fine of up to $250,000; under 15 U.S.C. 645 by imprisonment of not more
                            than two years and/or a fine of not more than $5,000; and, if submitted to a federally insured
                            institution, under 18 U.S.C. 1014 by imprisonment of not more than thirty years and/or a fine of
                            not more than $1,000,000.
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col xs={1}>
                                    <Form.Group controlId="certification10">
                                        <Form.Check
                                            onChange={handleChange}
                                            inline
                                            value={'true'}
                                            feedback={errors.certification10}
                                            isInvalid={!!errors.certification10}
                                            name="certification10"
                                        />
                                    </Form.Group>
                                </Col>
                                <Col xs={11}>
                            I acknowledge that the Lender will confirm the eligible loan amount using required documents
                            submitted. I understand, acknowledge, and agree that the Lender can share any tax information
                            that I have provided with SBA’s authorized representatives, including authorized representatives
                            of the SBA Office of Inspector General, for the purpose of compliance with SBA Loan Program
                            Requirements and all SBA reviews.
                                </Col>
                            </Row>
                            <RouteButtons previousPath={numberOfOwners === 1 ? '/first-applicant-owner' : '/second-applicant-owner'} />
                        </Form>
                    )}
                </Formik>
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { numberOfOwners, info } = state.user;
    return { numberOfOwners, info };
}

export default connect(mapStateToProps)(CertificationsDraw1);
