import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import CenteredContainer from '@common/CenteredContainer';
import RouteButtons from '@common/RouteButtons';
import {
    Form, Col,
} from 'react-bootstrap';
import FormControl from '@common/FormControl';
import { saveToState } from '@actions/actions';
import getColor from '@utils/getColor';
import {
    getUSYupDate, frontendToBackendDate, backendToFrontendDate, getBrowserDateFormat,
} from '@utils/dateUtils';
import { Formik } from 'formik';
import * as Yup from 'yup';

class ApplicantEntity extends PureComponent {
    componentDidMount() {
        const { applicantIsEligible } = this.props.info;
        if (!applicantIsEligible) {
            this.props.history.push('/questions');
        }
    }

    // Prevent submit on enter in input
    onKeyPress(event) {
        if (event.which === 13) {
            event.preventDefault();
        }
    }

    render() {
        const {
            routingNumber,
            accountNumber,
            businessName,
            businessAddressLine1,
            businessAddressLine2,
            businessCity,
            businessState,
            businessZipCode,
            businessTIN,
            businessTINType,
            businessPhoneNumber,
            businessNAICSCode,
            businessType,
            businessDBA,
            businessDateOfEstablishment,
            businessContactEmail,
            primaryContactFirstName,
            primaryContactLastName,
        } = this.props.info;

        const {
            accountNumberEndsWith,
            routingNumberEndsWith,
            businessTINEndsWith,
        } = this.props.endsWith;

        const schema = Yup.object({
            routingNumber: Yup.string()
                .matches(/^\+?([0-9]\d*)$/, 'Your entry is not valid. It must be a number.')
                .matches(new RegExp(`${routingNumberEndsWith}$`), `Your entry must ends with ${routingNumberEndsWith}`)
                .test('field-cannot-match', 'Routing Number should be different from Bank Account Number', function (value) {
                    return this.parent.accountNumber !== value;
                })
                .required('This is a required field'),
            accountNumber: Yup.string()
                .matches(/^\+?([0-9]\d*)$/, 'Your entry is not valid. It must be a number.')
                .matches(new RegExp(`${accountNumberEndsWith}$`), `Your entry must ends with ${accountNumberEndsWith}`)
                .test('field-cannot-match', 'Bank Account Number should be different from Routing Number', function (value) {
                    return this.parent.routingNumber !== value;
                })
                .required('This is a required field'),
            businessName: Yup.string().required('This is a required field'),
            businessAddressLine1: Yup.string().required('This is a required field'),
            businessAddressLine2: Yup.string(),
            businessCity: Yup.string().required('This is a required field'),
            businessState: Yup.string().required('This is a required field'),
            businessZipCode: Yup.string().matches(/^\d{5}$/, 'Your entry must be a 5 digit number').required('This is a required field'),
            businessTIN: Yup.string()
                .matches(/^\d{9}$/, 'Your entry must be a 9 digit number')
                .matches(new RegExp(`${businessTINEndsWith}$`), `Your entry must ends with ${businessTINEndsWith}`)
                .required('This is a required field'),
            businessTINType: Yup.string().required('This is a required field'),
            businessPhoneNumber: Yup.string().matches(/^\+?(0|[1-9]\d*)$/, 'Your entry is not valid').required('This is a required field'),
            businessNAICSCode: Yup.string().matches(/^\d{6}$/, 'Your entry must be a 6 digit number').required('This is a required field'),
            businessType: Yup.string().required('This is a required field'),
            businessDBA: Yup.string(),
            businessDateOfEstablishment: getUSYupDate().max(new Date(), 'Date cannot be in the future').required('This is a required field'),
            businessContactEmail: Yup.string().email('Your entry is not a valid email').required('This is a required field'),
            primaryContactFirstName: Yup.string().required('This is a required field'),
            primaryContactLastName: Yup.string().required('This is a required field'),
        });

        return (
            <CenteredContainer
                background={getColor('white')}
                foreground={getColor('dark')}
                desktopMargins={'65px 40px 65px 40px'}
                mobileMargins={'65px 40px 65px 40px'}
            >
                <h5>
                    <strong>Applicant Entity:</strong>
                </h5>
                <br/>
                <p className="text-small">
                    <img src="/dot.png" style={{ marginRight: 18 }} alt="Dot" />Required information
                </p>
                <br/>
                <Formik
                    validateOnChange={false}
                    validateOnBlur={false}
                    validationSchema={schema}
                    onSubmit={async (values) => {
                        const modifiedValues = {
                            routingNumber: values.routingNumber,
                            accountNumber: values.accountNumber,
                            businessName: values.businessName,
                            businessAddressLine1: values.businessAddressLine1,
                            businessAddressLine2: values.businessAddressLine2,
                            businessCity: values.businessCity,
                            businessState: values.businessState,
                            businessZipCode: values.businessZipCode.toString(),
                            businessTIN: values.businessTIN.toString(),
                            businessTINType: values.businessTINType,
                            businessPhoneNumber: values.businessPhoneNumber.toString(),
                            businessNAICSCode: values.businessNAICSCode.toString(),
                            businessType: values.businessType,
                            businessDBA: values.businessDBA,
                            businessDateOfEstablishment: frontendToBackendDate(values.businessDateOfEstablishment),
                            businessContactEmail: values.businessContactEmail,
                            primaryContactFirstName: values.primaryContactFirstName,
                            primaryContactLastName: values.primaryContactLastName,
                        };
                        await this.props.dispatch(saveToState(modifiedValues));
                        this.props.history.push('/application-details');
                    }}
                    initialValues={{
                        routingNumber,
                        accountNumber,
                        businessName,
                        businessAddressLine1,
                        businessAddressLine2,
                        businessCity,
                        businessState,
                        businessZipCode,
                        businessTIN,
                        businessTINType,
                        businessPhoneNumber,
                        businessNAICSCode,
                        businessType,
                        businessDBA,
                        businessDateOfEstablishment: backendToFrontendDate(businessDateOfEstablishment),
                        businessContactEmail,
                        primaryContactFirstName,
                        primaryContactLastName,
                    }}
                >
                    {({
                        handleSubmit,
                        handleChange,
                        values,
                        touched,
                        errors,
                    }) => (
                        <Form onKeyPress={this.onKeyPress} noValidate onSubmit={handleSubmit}>
                            <Form.Row>
                                <Col xs={12}>
                                    <FormControl
                                        label="Business Type"
                                        onChange={handleChange}
                                        as="select"
                                        value={values.businessType}
                                        name="businessType"
                                        isInvalid={!!errors.businessType}
                                        error={errors.businessType}
                                        required
                                    >
                                        <option value=""> -- Choose One -- </option>
                                        <option value="Sole Proprietor">Sole Proprietor</option>
                                        <option value="Partnership">Partnership</option>
                                        <option value="C-Corp">C-Corp</option>
                                        <option value="S-Corp">S-Corp</option>
                                        <option value="LLC">LLC</option>
                                        <option value="Independent Contractor">Independent Contractor</option>
                                        <option value="501(c)(3) nonprofit">501(c)(3) nonprofit</option>
                                        <option value="501(c)(6) organization">501(c)(6) organization</option>
                                        <option value="501(c)(19) veterans organization">501(c)(19) veterans organization</option>
                                        <option value="Eligible self-employed individual">Eligible self-employed individual</option>
                                        <option value="Housing Cooperative">Housing Cooperative</option>
                                        <option value="Tribal business (sec. 31(b)(2)(C) of Small Business Act)">Tribal business (sec. 31(b)(2)(C) of Small Business Act)</option>
                                        <option value="Nonprofit Organization">Nonprofit Organization</option>
                                        <option value="Other">Other</option>
                                    </FormControl>
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Bank Account Number"
                                        value={values.accountNumber}
                                        onChange={handleChange}
                                        type="string"
                                        name="accountNumber"
                                        isInvalid={!!errors.accountNumber}
                                        error={errors.accountNumber}
                                        required
                                        placeholder={accountNumberEndsWith ? `Please enter account number ending with ${accountNumberEndsWith}` : ''}
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Routing Number"
                                        value={values.routingNumber}
                                        onChange={handleChange}
                                        type="string"
                                        name="routingNumber"
                                        isInvalid={!!errors.routingNumber}
                                        error={errors.routingNumber}
                                        required
                                        placeholder={routingNumberEndsWith ? `Please enter routing number ending with ${routingNumberEndsWith}` : ''}
                                    />
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business Legal Name"
                                        value={values.businessName}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessName"
                                        isInvalid={!!errors.businessName}
                                        error={errors.businessName}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business Phone Number (No spaces or dashes)"
                                        value={values.businessPhoneNumber}
                                        onChange={handleChange}
                                        type="number"
                                        name="businessPhoneNumber"
                                        isInvalid={!!errors.businessPhoneNumber}
                                        error={errors.businessPhoneNumber}
                                        required
                                    />
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Primary Contact First Name"
                                        value={values.primaryContactFirstName}
                                        onChange={handleChange}
                                        type="text"
                                        name="primaryContactFirstName"
                                        isInvalid={!!errors.primaryContactFirstName}
                                        error={errors.primaryContactFirstName}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Primary Contact Last Name"
                                        value={values.primaryContactLastName}
                                        onChange={handleChange}
                                        type="text"
                                        name="primaryContactLastName"
                                        isInvalid={!!errors.primaryContactLastName}
                                        error={errors.primaryContactLastName}
                                        required
                                    />
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business Contact Email"
                                        value={values.businessContactEmail}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessContactEmail"
                                        isInvalid={!!errors.businessContactEmail}
                                        error={errors.businessContactEmail}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="DBA or Tradename"
                                        value={values.businessDBA}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessDBA"
                                        isInvalid={!!errors.businessDBA}
                                        error={errors.businessDBA}
                                    />
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business TIN (EIN, SSN)"
                                        value={values.businessTIN}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessTIN"
                                        isInvalid={!!errors.businessTIN}
                                        error={errors.businessTIN}
                                        required
                                        placeholder={businessTINEndsWith ? `Please enter business TIN ending with ${businessTINEndsWith}` : ''}
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business TIN Type"
                                        onChange={handleChange}
                                        as="select"
                                        value={values.businessTINType}
                                        name="businessTINType"
                                        isInvalid={!!errors.businessTINType}
                                        error={errors.businessTINType}
                                        required
                                    >
                                        <option value=""> -- Choose One -- </option>
                                        <option value="SSN">SSN</option>
                                        <option value="EIN">EIN</option>
                                    </FormControl>
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label={`Date of Establishment (${getBrowserDateFormat()})`}
                                        value={values.businessDateOfEstablishment}
                                        onChange={handleChange}
                                        type="date"
                                        name="businessDateOfEstablishment"
                                        isInvalid={!!errors.businessDateOfEstablishment}
                                        error={errors.businessDateOfEstablishment}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="NAICS Code"
                                        value={values.businessNAICSCode}
                                        onChange={handleChange}
                                        type="number"
                                        name="businessNAICSCode"
                                        isInvalid={!!errors.businessNAICSCode}
                                        error={errors.businessNAICSCode}
                                        required
                                    />
                                    <style jsx>{`
                                        .naicsLookup {
                                            font-size: 13px;
                                        }
                                    `}</style>
                                    <a className="naicsLookup" href="https://www.naics.com/code-search" target="_new">NAICS Code Lookup</a><br/>
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business Line Address 1"
                                        value={values.businessAddressLine1}
                                        onChange={handleChange}
                                        type="text"
                                        placeholder="1234 Main St"
                                        name="businessAddressLine1"
                                        isInvalid={!!errors.businessAddressLine1}
                                        error={errors.businessAddressLine1}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={6}>
                                    <FormControl
                                        label="Business Address Line 2"
                                        value={values.businessAddressLine2}
                                        onChange={handleChange}
                                        type="text"
                                        placeholder="Apartment, studio, or floor"
                                        name="businessAddressLine2"
                                        isInvalid={!!errors.businessAddressLine2}
                                        error={errors.businessAddressLine2}
                                    />
                                </Col>
                            </Form.Row>
                            <Form.Row>
                                <Col xs={12} lg={4}>
                                    <FormControl
                                        label="Business City"
                                        value={values.businessCity}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessCity"
                                        isInvalid={!!errors.businessCity}
                                        error={errors.businessCity}
                                        required
                                    />
                                </Col>
                                <Col xs={12} lg={4}>
                                    <FormControl
                                        label="Business State"
                                        value={values.businessState}
                                        onChange={handleChange}
                                        as="select"
                                        name="businessState"
                                        isInvalid={!!errors.businessState}
                                        error={errors.businessState}
                                        required
                                    >
                                        <option value=""> -- Choose One -- </option>
                                        <option value="AL">Alabama</option>
                                        <option value="AK">Alaska</option>
                                        <option value="AZ">Arizona</option>
                                        <option value="AR">Arkansas</option>
                                        <option value="CA">California</option>
                                        <option value="CO">Colorado</option>
                                        <option value="CT">Connecticut</option>
                                        <option value="DE">Delaware</option>
                                        <option value="DC">District Of Columbia</option>
                                        <option value="FL">Florida</option>
                                        <option value="GA">Georgia</option>
                                        <option value="HI">Hawaii</option>
                                        <option value="ID">Idaho</option>
                                        <option value="IL">Illinois</option>
                                        <option value="IN">Indiana</option>
                                        <option value="IA">Iowa</option>
                                        <option value="KS">Kansas</option>
                                        <option value="KY">Kentucky</option>
                                        <option value="LA">Louisiana</option>
                                        <option value="ME">Maine</option>
                                        <option value="MD">Maryland</option>
                                        <option value="MA">Massachusetts</option>
                                        <option value="MI">Michigan</option>
                                        <option value="MN">Minnesota</option>
                                        <option value="MS">Mississippi</option>
                                        <option value="MO">Missouri</option>
                                        <option value="MT">Montana</option>
                                        <option value="NE">Nebraska</option>
                                        <option value="NV">Nevada</option>
                                        <option value="NH">New Hampshire</option>
                                        <option value="NJ">New Jersey</option>
                                        <option value="NM">New Mexico</option>
                                        <option value="NY">New York</option>
                                        <option value="NC">North Carolina</option>
                                        <option value="ND">North Dakota</option>
                                        <option value="OH">Ohio</option>
                                        <option value="OK">Oklahoma</option>
                                        <option value="OR">Oregon</option>
                                        <option value="PA">Pennsylvania</option>
                                        <option value="RI">Rhode Island</option>
                                        <option value="SC">South Carolina</option>
                                        <option value="SD">South Dakota</option>
                                        <option value="TN">Tennessee</option>
                                        <option value="TX">Texas</option>
                                        <option value="UT">Utah</option>
                                        <option value="VT">Vermont</option>
                                        <option value="VA">Virginia</option>
                                        <option value="WA">Washington</option>
                                        <option value="WV">West Virginia</option>
                                        <option value="WI">Wisconsin</option>
                                        <option value="WY">Wyoming</option>
                                    </FormControl>
                                </Col>
                                <Col xs={12} lg={4}>
                                    <FormControl
                                        label="Business Zip Code"
                                        value={values.businessZipCode}
                                        onChange={handleChange}
                                        type="text"
                                        name="businessZipCode"
                                        isInvalid={!!errors.businessZipCode}
                                        error={errors.businessZipCode}
                                        required
                                    />

                                </Col>
                            </Form.Row>
                            <RouteButtons previousPath="/questions" />
                        </Form>)}
                </Formik>
            </CenteredContainer>
        );
    }
}

function mapStateToProps(state) {
    const { info, endsWith } = state.user;
    return { info, endsWith };
}

export default connect(mapStateToProps)(ApplicantEntity);
