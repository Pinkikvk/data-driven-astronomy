// Reducer export functions

export function __saveDocument({ file }) {
    return {
        type: 'SAVE_DOCUMENT',
        file,
    };
}

export function __saveInfo({ info }) {
    return {
        type: 'SAVE_INFO',
        info,
    };
}

export function __saveEndsWith({ endsWith }) {
    return {
        type: 'SAVE_ENDS_WITH',
        endsWith,
    };
}

export function __saveNumberOfOwners({ numberOfOwners }) {
    return {
        type: 'SAVE_NUMBER_OF_OWNERS',
        numberOfOwners,
    };
}

export function __saveJWT({ jwt }) {
    return {
        type: 'SAVE_JWT',
        jwt,
    };
}

export function __savePartner({ partner }) {
    return {
        type: 'SAVE_PARTNER',
        partner,
    };
}

export function __reloadSessionData(data) {
    return {
        type: 'RELOAD_SESSION_DATA',
        ...data,
    };
}

export function __startLoading() {
    return {
        type: 'START_LOADING',
    };
}

export function __clearSessionStorage() {
    sessionStorage.removeItem('ppp-data');
    return {
        type: 'CLEAR_SESSION_STORAGE',
    };
}

export function __triggerError(error) {
    return {
        type: 'TRIGGER_ERROR',
        error,
    };
}
