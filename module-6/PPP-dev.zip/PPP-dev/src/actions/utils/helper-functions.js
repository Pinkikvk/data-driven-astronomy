// Helper functions

// Function to check if the JWT token has expired
