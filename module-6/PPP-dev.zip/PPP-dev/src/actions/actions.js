import axios from 'axios';
import jwt_decode from 'jwt-decode';
import {
    __reloadSessionData,
    __saveInfo,
    __clearSessionStorage,
    __triggerError,
    __savePartner,
    __saveJWT,
    __saveDocument,
    __saveNumberOfOwners,
    __saveEndsWith,
} from './utils/reducer-functions';

export function uploadDocument(fileObject) {
    return async (dispatch) => {
        try {
            const formData = new FormData();
            formData.append('file', fileObject.file);
            formData.append('fileName', fileObject.fileName);

            const response = await axios.post('/file-upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            const file = response.data;
            dispatch(__saveDocument({ file }));
        } catch (error) {
            dispatch(__triggerError('Error while uploading document. Please contact us at support@jaris.io.'));
        }
    };
}

export function saveData({ info, numberOfOwners }) {
    return async (dispatch) => {
        try {
            const modifiedInfo = info;
            // We do this incase our prepopulation added fields but the user didnt step through second principal in the interface
            if (numberOfOwners === 1) {
                delete modifiedInfo.secondPrincipalName;
                delete modifiedInfo.secondPrincipalFirstName;
                delete modifiedInfo.secondPrincipalLastName;
                delete modifiedInfo.secondPrincipalTitle;
                delete modifiedInfo.secondPrincipalOwnershipPercentage;
                delete modifiedInfo.secondPrincipalTIN;
                delete modifiedInfo.secondPrincipalAddressLine1;
                delete modifiedInfo.secondPrincipalCity;
                delete modifiedInfo.secondPrincipalZipCode;
            }
            // VGS proxy
            await axios.post(`${process.env.REACT_APP_VGS_BASE_URL}/applications`, {
                ...modifiedInfo,
            });
        } catch (error) {
            const errorDescription = error?.response?.data?.description;
            let errorMessage;
            if (errorDescription && errorDescription.includes('already exists')) {
                errorMessage = 'You have already submitted the application. If there was an error in the claim, please contact us at support@jaris.io.';
            } else {
                errorMessage = 'Error while processing claim. c';
            }
            dispatch(__triggerError(errorMessage));
        }
    };
}

// Handler to reload the redux global state data saved in the session storage of the browser for persistence when reloading/refreshing
export function reloadSessionData() {
    return async (dispatch) => {
        try {
            const { jwt } = JSON.parse(sessionStorage.getItem('ppp-data'));
            // Check if jwt exists
            if (jwt) {
                axios.defaults.headers = {
                    Authorization: `Bearer ${jwt}`,
                };
                dispatch(__reloadSessionData(JSON.parse(sessionStorage.getItem('ppp-data'))));
            }
        } catch (error) {
            // Should the JWT not exist, clear the session storage ands the axios auth to ensure no data corruption
            delete axios.defaults.headers.Authorization;
            dispatch(__clearSessionStorage());
        }
    };
}

// Handler to login the client to the demo app and request all related data
export function login(jwtInQueryString) {
    return async (dispatch) => {
        try {
            // If there was a jwt token in the url address we don't need to log the person in, we just need to retrieve the data
            if (jwtInQueryString) {
                axios.defaults.headers = {
                    Authorization: `Bearer ${jwtInQueryString}`,
                };

                const { user_id, merchant_id } = jwt_decode(jwtInQueryString);
                const userId = user_id;
                const merchantId = merchant_id;
                const response = await axios.get(`/merchants/${merchantId}`);
                const merchant = response.data;

                let firstPrincipal = {};
                let secondPrincipal = {};

                const main = {
                    userId,
                    merchantId,
                    businessName: merchant.legal_name ? merchant.legal_name : '',
                    businessAddressLine1: merchant.address_street ? merchant.address_street : '',
                    businessCity: merchant.address_city ? merchant.address_city : '',
                    businessZipCode: merchant.address_zip ? merchant.address_zip : '',
                    businessPhoneNumber: merchant.phone_fixed ? merchant.phone_fixed : '',
                    businessDBA: merchant.doing_business_as ? merchant.doing_business_as : '',
                    businessContactFullName: merchant.primaryOwners[0].first_name && merchant.primaryOwners[0].last_name ? `${merchant.primaryOwners[0].first_name} ${merchant.primaryOwners[0].last_name}` : '',
                    businessContactEmail: merchant.primaryOwners[0].email ? merchant.primaryOwners[0].email : '',
                    businessContactPhoneNumber: merchant.primaryOwners[0].phone_fixed ? merchant.primaryOwners[0].phone_fixed : '',
                };

                const endsWith = {
                    accountNumberEndsWith: merchant.banking_info && merchant.banking_info.length >= 1 && merchant.banking_info[0].account ? merchant.banking_info[0].account.substring(merchant.banking_info[0].account.length - 4) : '',
                    routingNumberEndsWith: merchant.banking_info && merchant.banking_info.length >= 1 && merchant.banking_info[0].routing ? merchant.banking_info[0].account.substring(merchant.banking_info[0].routing.length - 4) : '',
                    businessTINEndsWith: merchant.tax_id ? merchant.tax_id.substring(merchant.tax_id.length - 4) : '',
                };

                if (merchant.primaryOwners && merchant.primaryOwners.length >= 1) {
                    firstPrincipal = {
                        firstPrincipalName: merchant.doing_business_as ? merchant.doing_business_as : '',
                        firstPrincipalFirstName: merchant.primaryOwners[0].first_name ? merchant.primaryOwners[0].first_name : '',
                        firstPrincipalLastName: merchant.primaryOwners[0].last_name ? merchant.primaryOwners[0].last_name : '',
                        firstPrincipalTitle: merchant.primaryOwners[0].title ? merchant.primaryOwners[0].title : '',
                        firstPrincipalOwnershipPercentage: merchant.primaryOwners[0].ownership_fraction ? parseFloat(merchant.primaryOwners[0].ownership_fraction) : null,
                        firstPrincipalAddressLine1: merchant.primaryOwners[0].street ? merchant.primaryOwners[0].street : '',
                        firstPrincipalCity: merchant.primaryOwners[0].address_city ? merchant.primaryOwners[0].address_city : '',
                        firstPrincipalZipCode: merchant.primaryOwners[0].address_zip ? merchant.primaryOwners[0].address_zip : '',
                    };
                    endsWith.firstPrincipalTINEndsWith = merchant.primaryOwners[0].tax_id ? merchant.primaryOwners[0].tax_id.substring(merchant.primaryOwners[0].tax_id.length - 4) : '';
                }

                if (merchant.primaryOwners && merchant.primaryOwners.length >= 2) {
                    secondPrincipal = {
                        secondPrincipalName: merchant.doing_business_as ? merchant.doing_business_as : '',
                        secondPrincipalFirstName: merchant.primaryOwners[1].first_name ? merchant.primaryOwners[1].first_name : '',
                        secondPrincipalLastName: merchant.primaryOwners[1].last_name ? merchant.primaryOwners[1].last_name : '',
                        secondPrincipalTitle: merchant.primaryOwners[1].title ? merchant.primaryOwners[1].title : '',
                        secondPrincipalOwnershipPercentage: merchant.primaryOwners[1].ownership_fraction ? parseFloat(merchant.primaryOwners[1].ownership_fraction) : '',
                        secondPrincipalTIN: merchant.primaryOwners[1].tax_id ? merchant.primaryOwners[1].tax_id : '',
                        secondPrincipalAddressLine1: merchant.primaryOwners[1].street ? merchant.primaryOwners[1].street : '',
                        secondPrincipalCity: merchant.primaryOwners[1].address_city ? merchant.primaryOwners[1].address_city : '',
                        secondPrincipalZipCode: merchant.primaryOwners[1].address_zip ? merchant.primaryOwners[1].address_zip : '',
                    };
                    endsWith.secondPrincipalTINEndsWith = merchant.primaryOwners[1].tax_id ? merchant.primaryOwners[1].tax_id.substring(merchant.primaryOwners[1].tax_id.length - 4) : '';
                }

                // We save all data to pre-populate in the state
                dispatch(__saveJWT({ jwt: jwtInQueryString }));
                dispatch(__saveInfo({ info: { ...main, ...firstPrincipal, ...secondPrincipal } }));
                dispatch(__saveEndsWith({ endsWith }));
            }
        } catch (error) {
            // Something went wrong
            dispatch(__triggerError('Error while connecting partner. Please contact us at support@jaris.io.'));
        }
    };
}

// Handler to login the partner to the demo app and request all related data
export function loginPartner(partner) {
    return async (dispatch) => {
        try {
            // We do this to be able to have the partner in any case
            const response = await axios.post('/users', { partner });
            const { accessToken: jwt, userId } = response.data;

            axios.defaults.headers = {
                Authorization: `Bearer ${jwt}`,
            };

            dispatch(__saveJWT({ jwt }));
            dispatch(__savePartner({ partner }));
            dispatch(__saveInfo({ info: { userId } }));
        } catch (error) {
            // Something went wrong
            dispatch(__triggerError('Error while logging in partner. Please contact us at support@jaris.io.'));
        }
    };
}

// Save partner to cascade design
export function setPartner(partner) {
    return async (dispatch) => {
        dispatch(__savePartner({ partner }));
    };
}

// Append ppp form data to global redux state
export function saveToState(info) {
    return async (dispatch) => {
        dispatch(__saveInfo({ info }));
    };
}

// Save number of owners to see how many owner forms we show to the user
export function saveNumberOfOwners(numberOfOwners) {
    return async (dispatch) => {
        dispatch(__saveNumberOfOwners({ numberOfOwners }));
    };
}
