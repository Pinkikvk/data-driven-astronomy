import React, { Component } from 'react';
import './App.css';
import { connect } from 'react-redux';
import { BrowserRouter as Router, Switch } from 'react-router-dom';
import queryString from 'query-string';
import {
    login, loginPartner, reloadSessionData, setPartner,
} from '@actions/actions';
import ScrollToTop from '@common/ScrollToTop';
import GARoute from '@common/GARoute';
import Header from '@common/Header';
import Footer from '@common/Footer';
import NotFound from '@common/NotFound';
import { partnerMap } from '@/api-config/partners';
import Welcome from './views/Welcome';
import PurposeOfFormDraw1 from './views/PurposeOfFormDraw1';
import PurposeOfFormDraw2 from './views/PurposeOfFormDraw2';
import Questions from './views/Questions';
import ApplicantEntity from './views/ApplicantEntity';
import FirstApplicantOwner from './views/FirstApplicantOwner/FirstApplicantOwner';
import SecondApplicantOwner from './views/SecondApplicantOwner/SecondApplicantOwner';
import ApplicationDetails from './views/ApplicationDetails';
import DrawSelector from './views/DrawSelector';
import CertificationsDraw1 from './views/CertificationsDraw1';
import CertificationsDraw2 from './views/CertificationsDraw2';
import AdditionalTerms from './views/AdditionalTerms';
import Processed from './views/Processed';
import ErrorPage from './views/common/ErrorPage';
import setAxiosDefaultConfiguration from './api-config/api';

class App extends Component {
    componentWillMount() {
        // When the component first renders set the baseURL from the env file
        setAxiosDefaultConfiguration();
        // We parse the URL
        const queryStringParameters = queryString.parse(window.location.search);
        const parsedPppData = sessionStorage.getItem('ppp-data') && JSON.parse(sessionStorage.getItem('ppp-data'));

        const { partner } = queryStringParameters;
        const partnerLowerCase = partner && partnerMap[partner.toLowerCase()] ? partner.toLowerCase() : 'jaris';

        if (queryStringParameters.jwt) {
            if (parsedPppData?.jwt) {
                this.props.dispatch(reloadSessionData());
                window.gtag('event', 'reloading_application');
            } else {
                this.props.dispatch(login(queryStringParameters.jwt));
                this.props.dispatch(setPartner(partnerLowerCase));
                window.gtag('event', 'loading_application_jwt_');
            }
        } else if (parsedPppData?.jwt) {
            this.props.dispatch(reloadSessionData());
            window.gtag('event', 'reloading_application');
        } else {
            this.props.dispatch(loginPartner(partnerLowerCase));
            window.gtag('event', `loading_application_${partnerLowerCase}`);
        }
    }

    render() {
        const { error } = this.props;

        if (error) {
            return (
                <div className="app">
                    <Header />
                    <div style={{ textAlign: 'center', height: '100%' }}>
                        <ErrorPage/>
                    </div>
                    <Footer />
                    <style jsx>{`
                        .app {
                            height: 100%;
                            margin-bottom: -65px;
                        }
                    `}</style>
                </div>
            );
        }

        return (
            <div className="app">
                <Header />
                <Router>
                    <ScrollToTop />
                    <Switch>
                        <GARoute path="/" exact component={Welcome} />
                        <GARoute path="/draw-selector" exact component={DrawSelector} />
                        <GARoute path="/purpose-of-form-draw-1" exact component={PurposeOfFormDraw1} />
                        <GARoute path="/purpose-of-form-draw-2" exact component={PurposeOfFormDraw2} />
                        <GARoute path="/questions" exact component={Questions} />
                        <GARoute path="/applicant-entity" exact component={ApplicantEntity} />
                        <GARoute path="/first-applicant-owner" exact component={FirstApplicantOwner} />
                        <GARoute path="/second-applicant-owner" exact component={SecondApplicantOwner} />
                        <GARoute path="/application-details" exact component={ApplicationDetails} />
                        <GARoute path="/certifications-draw-1" exact component={CertificationsDraw1} />
                        <GARoute path="/certifications-draw-2" exact component={CertificationsDraw2} />
                        <GARoute path="/additional-terms" exact component={AdditionalTerms} />
                        <GARoute path="/processed" exact component={Processed} />
                        { /* Catches all unmatched routes */ }
                        <GARoute component={NotFound} />
                    </Switch>
                </Router>
                <Footer />
                <style global jsx>{`
                    .app {
                        height: 100%;
                        margin-bottom: -65px;
                    }
                    .form-label {
                        margin-top: 15px;
                    }
                `}</style>
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { error } = state.user;
    return { error };
}

export default connect(mapStateToProps)(App);
