import axios from 'axios';

// Grab the base url variable from the env file
const setAxiosDefaultConfiguration = () => {
    axios.defaults.baseURL = process.env.REACT_APP_API_BASE_URL;
};

// Function called in app.js
export default setAxiosDefaultConfiguration;
