export const partnerMap = {
    spoton: 'SpotOn',
    honeybook: 'HoneyBook',
};
