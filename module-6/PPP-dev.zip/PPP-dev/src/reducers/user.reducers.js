const initialState = {
    jwt: null,
    partner: null,
    numberOfOwners: '',
    endsWith: {
        accountNumberEndsWith: '',
        routingNumberEndsWith: '',
        businessTINEndsWith: '',
        firstPrincipalTINEndsWith: '',
        secondPrincipalTINEndsWith: '',
    },
    info: {
        userId: null,
        merchantId: null,
        loanOfficer: '', // Always pass back empty
        secondDrawPppLoan: null,
        ineligibleGeneral: null,
        ineligibleBadLoan: null,
        applicantIsEligible: null,
        applicantMeetsRevenueTestAndSizeStandard: null,
        hasOtherBusinesses: null,
        addendumA: '',
        receivedEIDL: null,
        addendumB: '',
        ineligibleCriminalCharges: null,
        ineligibleFelony: null,
        allEmployeesResidency: null,
        businessFranchiseStatus: '',
        businessFranchiseinSBADirectory: '',
        businessFranchiseCode: '',
        // * This entire section is set to true because they correlate with the ineligibleFields.
        allProposedCrimesAreMisdemeanors: true,
        guarantorsAreNotIneligible: true,
        guarantorsHaveNotCausedLoss: true,
        guarantorsAreNotIndicted: true,
        // *
        routingNumber: '',
        accountNumber: '',
        businessName: '',
        businessAddressLine1: '',
        businessAddressLine2: '',
        businessCity: '',
        businessState: '',
        businessZipCode: '',
        businessTIN: '',
        businessTINType: '',
        businessPhoneNumber: '',
        businessNAICSCode: '',
        businessType: '',
        businessDBA: '',
        businessDateOfEstablishment: '',
        businessContactEmail: '',
        primaryContactFirstName: '',
        primaryContactLastName: '',
        purposeOfLoanPayroll: false,
        purposeOfLoanMortgage: false,
        purposeOfLoanUtilities: false,
        purposeOfLoanCoveredOperationsExpenditures: false,
        purposeOfLoanCoveredPropertyDamage: false,
        purposeOfLoanCoveredSupplierCosts: false,
        purposeOfLoanCoveredWorkerProtectionExpenditure: false,
        purposeOfLoanOther: false,
        purposeOfLoanOtherInfo: '',
        averageMonthlyPayroll: '',
        loanAmount: '',
        refinanceofEIDLNetOfAdvance: '',
        numberOfEmployeesAtTimeOfApplication: '',
        anticipatedNumberOfEmployeesRetained: '',
        applicantMeetsSizeStandard: '',
        payrollFiles: [],
        firstDrawSBALoanNumber: '',
        firstDrawSBALoanAmount: '',
        referenceQuarter: '',
        twentyTwentyQuarter: '',
        period1Revenue: '',
        period2Revenue: '',
        // Certifications fields
        loanRequestIsNecessary: false,
        applicantNoShutteredVenueGrant: false,
        lenderCertifiedGrossReceiptsReduction: false,
        applicantReceivesOneSecondDrawLoan: false,
    },
};

// Function to store redux state in session storage
function saveInSessionStorage(newState) {
    sessionStorage.setItem('ppp-data', JSON.stringify(newState));
}

const user = (state = initialState, action) => {
    if (sessionStorage.getItem('ppp-data')) {
        console.log(JSON.parse(sessionStorage.getItem('ppp-data')));
    }

    switch (action.type) {
        case 'FETCH_MERCHANT_DATA':
        {
            const newState = {
                ...state,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_DATA':
        {
            const newState = {
                ...initialState,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_ENDS_WITH':
        {
            const newState = {
                ...state,
                endsWith: { ...state.endsWith, ...action.endsWith },
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_NUMBER_OF_OWNERS':
        {
            const newState = {
                ...state,
                numberOfOwners: action.numberOfOwners,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_JWT':
        {
            const newState = {
                ...state,
                jwt: action.jwt,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_PARTNER':
        {
            const newState = {
                ...state,
                partner: action.partner,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_DOCUMENT':
        {
            // Add new file to array
            const { payrollFiles } = state.info;
            payrollFiles.push(action.file);
            const newState = {
                ...state,
                info: {
                    ...state.info,
                    payrollFiles,
                },
                atLeastOnePayrollFile: 'true',
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'SAVE_INFO':
        {
            const newState = {
                ...state,
                info: {
                    ...state.info,
                    ...action.info,
                },
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'RELOAD_SESSION_DATA':
        {
            const newState = {
                ...state,
                ...action,
                error: false,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'CLEAR_SESSION_STORAGE':
        {
            saveInSessionStorage(initialState);
            return initialState;
        }
        case 'START_LOADING':
        {
            const newState = {
                ...state,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        case 'TRIGGER_ERROR':
        {
            const newState = {
                ...state,
                error: action.error,
            };
            saveInSessionStorage(newState);
            return newState;
        }
        default:
            return state;
    }
};

export default user;
