import { combineReducers } from 'redux';
import user from './user.reducers';

export default combineReducers({
    user,
});
