import * as Yup from 'yup';
import * as Moment from 'moment';

const FRONTEND_DATE_FORMAT = 'MM-DD-YYYY';
const BACKEND_DATE_FORMAT = 'DD-MM-YYYY';

export function getBrowserDateFormat() {
    const date = new Date(2000, 11, 31);
    let stringDate = date.toLocaleDateString();
    stringDate = stringDate.replace('31', 'dd');
    stringDate = stringDate.replace('12', 'mm');
    stringDate = stringDate.replace('2000', 'yyyy');
    return stringDate;
}

export function getUSYupDate() {
    return Yup.date()
        .transform((value, originalValue) => {
            value = Moment(originalValue, getBrowserDateFormat().toUpperCase(), true);
            return value.isValid() ? value.toDate() : Yup.date.INVALID_DATE;
        })
        .typeError(`Your entry is not the valid format (${getBrowserDateFormat()})`);
}

function reformatStringDate(stringDate, sourceFormat, targetFormat) {
    if (stringDate) {
        const date = Moment(stringDate, sourceFormat, true);
        if (date.isValid()) {
            return date.format(targetFormat);
        }
    }

    return '';
}

export function frontendToBackendDate(frontendStringDate) {
    return reformatStringDate(frontendStringDate, FRONTEND_DATE_FORMAT, BACKEND_DATE_FORMAT);
}

export function backendToFrontendDate(backednStringDate) {
    return reformatStringDate(backednStringDate, BACKEND_DATE_FORMAT, FRONTEND_DATE_FORMAT);
}
