export default function (string) {
    if (string === 'true') {
        return true;
    } else {
        return false;
    }
}
