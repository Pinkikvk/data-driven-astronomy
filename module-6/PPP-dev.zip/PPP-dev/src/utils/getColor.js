const customColors = {
    black: '#000000',
    white: '#FFFFFF',
    dark: '#161B22',
    'honeybook-background-color': '#000021',
    'honeybook-text-color': '#A8ADB8',
    'spoton-background-color': '#114958',
    'spoton-text-color': '#FFFFFF',
    'jaris-background-color': '#161B22',
    'jaris-text-color': '#FFFFFF',
};

export default function (color) {
    return customColors[color] || color;
}
