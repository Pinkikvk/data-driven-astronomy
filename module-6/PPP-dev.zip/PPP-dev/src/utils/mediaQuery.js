const breakPointSmall = 992;

exports.onDesktop = `min-width: ${breakPointSmall}px`;
