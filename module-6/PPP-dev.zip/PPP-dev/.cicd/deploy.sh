#!/bin/bash

set -eu

INSTANCE="${STAGE}-ppp-us"

slack_notification() {
	curl -X POST -H 'Content-type: application/json' \
		--data "{\"text\":\":heavy_check_mark: (${INSTANCE}): Application ${SERVICE_NAME} has been successfully deployed\"}" \
		${SLACK_DEPLOY_URL}
}


if [[ ${STAGE} == "prod" ]]; then
  cat << EOF > .env
REACT_APP_API_BASE_URL=https://prod.api.ppp.us.jaris.io
REACT_APP_VGS_BASE_URL=https://tntazjlklnx.live.verygoodproxy.com
REACT_APP_PACTSAFE_ACCESS_ID=c22b0ebe-f18c-44ef-a1ff-475e4c5105b4
REACT_APP_PACTSAFE_GROUP_KEY=group-s1joha-ap
REACT_APP_GOOGLE_ANALYTICS_ID=G-D29FM5TBQ8
EOF
fi

echo "[status] environment settings for ${STAGE}"
cat .env

case $STAGE in
  "dev") CLOUD_FRONT_DISTRIBUTION_ID="E16JQ85RIIMRUW";;
  "prod") CLOUD_FRONT_DISTRIBUTION_ID="E3NPAOHU5BT9XT";;
  "*")  echo "No cloudfront distribution id found."
        exit 1;;
esac

npm install
CI="false" npm run build  # Or npm run-script build if the previous command doesn't work

aws s3 cp --recursive build/ s3://jaris.website.us.ppp.${STAGE}/

aws cloudfront create-invalidation --distribution-id=${CLOUD_FRONT_DISTRIBUTION_ID} --paths "/*"

slack_notification
